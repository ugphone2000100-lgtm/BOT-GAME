"""Test THẬT v102: THÔNG BÁO HẾT THỜI GIAN ĐẶT CƯỢC.

- Render tin nhắn qua hàm THẬT bot._bet_time_up_text().
- Gửi THẬT lên nhóm Telegram, đếm entities custom_emoji (premium) + bold.
- Kiểm tra: tiêu đề "Hết thời gian đặt cược phiên #N", TÀI/XỈU/CHẴN/LẺ đúng tổng,
  có dòng trống giữa nhóm TÀI/XỈU và CHẴN/LẺ, tất cả in đậm.
- Lưu JSON bằng chứng.
"""
import json
import os
import re
import time

os.environ.setdefault("TZ", "Asia/Bangkok")
try:
    time.tzset()
except Exception:  # noqa: BLE001
    pass

import bot  # noqa: E402

UID = "999000102"
NAME = "TestUser102"
TOKEN = bot.config.TELEGRAM_BOT_TOKEN
CHAT = bot.config.TELEGRAM_CHAT_ID
ROUND_NO = 80307
OUT = {"version": "v102", "feature": "bet_time_up", "round_no": ROUND_NO, "steps": []}


def send_group(text):
    import urllib.parse
    import urllib.request
    if not TOKEN or not CHAT:
        return None, 0, 0
    try:
        url = f"https://api.telegram.org/bot{TOKEN}/sendMessage"
        payload = urllib.parse.urlencode({
            "chat_id": CHAT, "text": text, "parse_mode": "HTML",
            "disable_web_page_preview": "true"}).encode()
        with urllib.request.urlopen(urllib.request.Request(url, data=payload), timeout=20) as r:
            d = json.loads(r.read().decode())
        if not d.get("ok"):
            print("send fail", d)
            return None, 0, 0
        res = d["result"]
        ents = res.get("entities") or []
        n_prem = sum(1 for e in ents if e.get("type") == "custom_emoji")
        n_bold = sum(1 for e in ents if e.get("type") == "bold")
        return res.get("message_id"), n_prem, n_bold
    except Exception as e:  # noqa: BLE001
        print("send err", e)
        return None, 0, 0


# --- 1) ĐẶT CƯỢC THẬT để tích lũy (chứng minh luồng thật) ---
st = bot.store
u = st.get_user(UID)
u["balance"] = 50_000_000
u["username"] = NAME
u.setdefault("stats", {})
u["stats"]["wagered"] = 0
st.save()

bot._round.phase = "betting"
bot._round.round_no = ROUND_NO
bot._round.round_code = str(ROUND_NO)
r1 = bot._telegram_bet_handler(UID, NAME, "T 58784")
OUT["steps"].append({"act": "real_bet_T_58784", "reply": r1})
bot._round.phase = "idle"

# --- 2) RENDER tin HẾT THỜI GIAN ĐẶT CƯỢC qua hàm THẬT ---
bets = {UID: [{"bet": "tai", "amount": 58784}]}
text = bot._bet_time_up_text(ROUND_NO, bets)
OUT["rendered_text"] = text
OUT["rendered_plain"] = re.sub(r"<[^>]+>", "", text)

# --- 3) GỬI THẬT lên nhóm ---
mid, n_prem, n_bold = send_group(text)
OUT["msg_id"] = mid
OUT["premium_emoji_count"] = n_prem
OUT["bold_entity_count"] = n_bold

# --- 4) KIỂM TRA ---
plain = OUT["rendered_plain"]
checks = {
    "title_ok": f"Hết thời gian đặt cược phiên #{ROUND_NO}" in plain,
    "tai_ok": "🔵 TÀI: 58.784" in plain,
    "xiu_ok": "🔴 XỈU: 0" in plain,
    "chan_ok": "⚪️ CHẴN: 0" in plain,
    "le_ok": "⚫️ LẺ: 0" in plain,
    "blank_line_ok": "\n\n" in plain,
    "all_bold_ok": n_bold >= 5,
    "sent_ok": bool(mid),
}
OUT["checks"] = checks
OUT["all_pass"] = all(checks.values())
OUT["ts_str"] = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())

os.makedirs("evidence", exist_ok=True)
with open("evidence/result_v102_bettimeup.json", "w", encoding="utf-8") as f:
    json.dump(OUT, f, ensure_ascii=False, indent=2)

print(json.dumps(OUT, ensure_ascii=False, indent=2))
print("ALL_PASS =", OUT["all_pass"])
