#!/usr/bin/env bash
# run_forever.sh (v100) — Chay bot Tai Xiu (Telegram) LIEN TUC, tu khoi dong lai khi crash/bi kill.
# =============================================================================
# v80: DOI TOAN BO EMOJI PREMIUM sang goi "News Emoji" (https://t.me/addemoji/NewsEmoji).
#      Giu nguyen toan bo chuc nang v79 (countdown 2 tin 40s/20s, gio Thai Lan, DM...).
# v79: COUNTDOWN 2 TIN TEXT/PHIEN (moc 40s + moc 20s) roi tung luon; gio Thai Lan (Asia/Bangkok).
# v68: LUONG NAP TIEN HOAN CHINH: nut "Nap tien tai day" -> tin nhan "Chon menh gia nap"
#      + 10 nut menh gia (20k..10M); bam menh gia (hoac /nap <so tien>) -> gui QR VietQR
#      (VIB 810065 - TTNS) + thong tin nap + tao deposit_request pending.
#      Giu nguyen toan bo chuc nang v63.
# v63: TRANG "NAP / RUT" tren web admin: admin DUYET / TU CHOI yeu cau nap + rut
#      (ghi truc tiep data.json + gui thong bao Telegram cho user). Them lenh /nap
#      de nguoi choi tao yeu cau nap. Giu nguyen toan bo chuc nang v61.
# v61: BAT PUBLIC LINK cho web admin (cloudflared quick tunnel --protocol http2) + watchdog
#      giu tunnel song 24/7. URL public ghi dong vao webadmin_url.txt; lenh /webadmin tra link that.
# v60: NUT "RUT TIEN" YEU CAU LIEN KET STK: bam "Rut tien" -> neu CHUA co STK thi bot
#      yeu cau nhap STK (so TK + ngan hang + chu TK), luu vao data.json gan voi user;
#      co STK roi thi hien STK da lien ket + nut "Xac nhan rut tien" (tao yeu cau rut KEM STK).
#      Them lenh /stk (xem & doi STK). /webadmin: AN khoi menu nhung ADMIN (thandam789) van dung duoc.
# v59: NUT "RUT TIEN" THUC SU HOAT DONG: nut tren ANH chi la HINH VE (khong bam duoc)
#      -> them InlineKeyboard THAT (2 nut bam duoc: "Nap tien tai day" + "Rut tien")
#      gan duoi anh the phien; bam "Rut tien" -> bot GHI NHAN yeu cau rut vao data.json
#      va gui 1 TIN NHAN THONG BAO MOI (khung ┌│└ + in dam). Nut ReplyKeyboard "Rut Tien"
#      cung ghi nhan yeu cau rut that.
# v58: NUT "RUT TIEN" theo ANH MAU: them nut "Rut tien" (emoji premium 🏦, chu VANG)
#      canh nut "Nap tien tai day" TREN ANH the phien. 8 nut ReplyKeyboard giu nguyen.
# v57: DOI TEN THUONG HIEU TREN ANH: "ET88" -> "ET99" (header "ET99 - TUNG XX").
# v56: ANH DEM NGUOC + ANH MO PHIEN bam sat ANH MAU nguoi dung (the cuoc
#      "ET99 - TUNG XX").
# Dung:
#   chmod +x run_forever.sh
#   setsid nohup ./run_forever.sh > /dev/null 2>&1 < /dev/null &
# Dung:  pkill -f run_forever.sh ; pkill -f bot.py
# Log:   tail -f bot_forever_v102.log
# =============================================================================
set -u

cd "$(dirname "$0")" || exit 1

export TZ=Asia/Bangkok
export PATH="/usr/local/bin:$PATH"   # v87: cron PATH thieu /usr/local/bin -> thieu module dotenv
LOG="bot_forever_v102.log"
BOTLOG="bot_run_v102.log"
LOCK="run_forever_v102.lock"

# --- LOCK: chi cho phep 1 supervisor chay ---
if [ -f "$LOCK" ]; then
    OLD=$(cat "$LOCK" 2>/dev/null)
    if [ -n "$OLD" ] && kill -0 "$OLD" 2>/dev/null; then
        echo "⚠️ [$(date '+%Y-%m-%d %H:%M:%S')] Supervisor da chay (PID $OLD) — thoat de tranh trung." >> "$LOG"
        exit 0
    fi
fi
echo $$ > "$LOCK"
trap 'rm -f "$LOCK"' EXIT

echo "🚀 [$(date '+%Y-%m-%d %H:%M:%S')] keep-alive v81 khởi động (PID $$) — log: $LOG" >> "$LOG"

while true; do
    echo "===== $(date '+%Y-%m-%d %H:%M:%S') — khởi động bot (v100) =====" >> "$LOG"
    python3 -u bot.py >> "$BOTLOG" 2>&1
    code=$?
    echo "⚠️ [$(date '+%Y-%m-%d %H:%M:%S')] Bot dừng (exit code $code). Khởi động lại sau 5 giây..." >> "$LOG"
    sleep 5
done
