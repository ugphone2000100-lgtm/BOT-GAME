#!/usr/bin/env bash
# start_tunnel_lhr.sh (v100) — Tunnel DU PHONG qua localhost.run (SSH) khi trycloudflare bi chan (429).
# Giu web admin Flask 127.0.0.1:5000 public 24/7; ghi URL that vao webadmin_url.txt (dong).
set -u
cd "$(dirname "$0")" || exit 1
export TZ=Asia/Bangkok
export PATH="/usr/local/bin:$PATH"   # v87: cron PATH thieu /usr/local/bin -> thieu module dotenv
LOG="tunnel_v102.log"
URL_FILE="webadmin_url.txt"
SSHLOG="cf_lhr_v102.log"
LOCK="tunnel_lhr_v102.lock"
ts() { date '+%Y-%m-%d %H:%M:%S'; }

if [ -f "$LOCK" ]; then
  OLD=$(cat "$LOCK" 2>/dev/null)
  if [ -n "$OLD" ] && kill -0 "$OLD" 2>/dev/null; then
    echo "⚠️ [$(ts)] Tunnel LHR đã chạy (PID $OLD) — thoát." >> "$LOG"; exit 0
  fi
fi
echo $$ > "$LOCK"; trap 'rm -f "$LOCK"' EXIT

# dam bao Flask web admin song
if ! pgrep -f "webadmin.py" >/dev/null 2>&1; then
  setsid nohup python3 -u webadmin.py > "web_run_v102.log" 2>&1 < /dev/null &
  sleep 3
fi

echo "🚀 [$(ts)] Tunnel LHR supervisor khởi động (PID $$)" >> "$LOG"
while true; do
  : > "$SSHLOG"
  setsid nohup ssh -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null \
        -o ServerAliveInterval=20 -o ExitOnForwardFailure=yes \
        -R 80:localhost:5000 nokey@localhost.run > "$SSHLOG" 2>&1 < /dev/null &
  URL=""
  for _ in $(seq 1 40); do
    URL=$(grep -oE "https://[a-z0-9]+\.lhr\.life" "$SSHLOG" 2>/dev/null | head -1)
    [ -n "$URL" ] && break
    sleep 1
  done
  if [ -n "$URL" ]; then
    echo "$URL" > "$URL_FILE"
    echo "✅ [$(ts)] URL public (lhr): $URL" >> "$LOG"
  else
    echo "⚠️ [$(ts)] Chưa lấy được URL lhr, thử lại..." >> "$LOG"
  fi
  # giu tunnel: neu ssh chet, vong lap se bat lai
  while pgrep -f "localhost.run" >/dev/null 2>&1; do sleep 20; done
  echo "♻️ [$(ts)] Tunnel lhr đứt -> bật lại sau 5s" >> "$LOG"
  sleep 5
done
