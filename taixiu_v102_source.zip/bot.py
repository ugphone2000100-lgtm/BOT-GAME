"""
bot.py — Bot Tài Xỉu (Over/Under) CHỈ CHẠY TELEGRAM.
====================================================

Bản _v35: ĐÃ XOÁ TOÀN BỘ DISCORD (không còn discord.py, không slash command,
không token Discord). Bot chỉ chạy Telegram + web admin Flask.

Chạy:
    python bot.py

Vòng lặp phiên Tài Xỉu (mỗi ROUND_INTERVAL giây):
    Đếm ngược (mở cược, đăng lên nhóm Telegram) → khóa cược →
    TUNG 3 XÚC XẮC BÊN TELEGRAM (sendDice 🎲) → gửi ảnh + kết quả về nhóm Telegram → trả thưởng.

Đặt cược:
    Người chơi gõ TIN NHẮN CHAT THƯỜNG trong nhóm Telegram (KHÔNG cần dấu /):
        T 200k X 200k L 500K C 500K
    Quy ước: T=Tài, X=Xỉu, C=Chẵn, L=Lẻ, B=Bão; k/K=nghìn, m/M=triệu (hoặc số đầy đủ).
    Chỉ tin nhắn khớp đúng dạng cược mới được xử lý; chat thường khác bị bỏ qua.

Lệnh Telegram (gõ trong chat Telegram):
    /start, /help                    Bắt đầu / xem ID
    (v53) /addcoin <user_id> <số xu> [Admin ẨN] Cộng xu — KHÔNG hiện trong menu, người thường bị im lặng
    (v53) /webadmin                  [Admin ẨN] Đã bỏ khỏi menu; web admin chỉ chạy localhost

Cấu hình qua .env:
    TELEGRAM_BOT_TOKEN=...     # token bot Telegram (BotFather) — KHÔNG hardcode
    TELEGRAM_CHAT_ID=-100...   # ID nhóm Telegram
    ROUND_INTERVAL=30          # chu kỳ mỗi phiên (giây)
    ADMIN_PASSWORD=admin123    # mật khẩu web admin
    DATA_FILE=data.json        # file dữ liệu chung với web admin
"""
import asyncio
from datetime import timedelta
import hashlib
import json
import os
import random
import string
import sys
import time

# --- Múi giờ Thái Lan (Asia/Bangkok, UTC+7) cho MỌI thời gian hiển thị/ghi ---
os.environ.setdefault("TZ", "Asia/Bangkok")
try:
    time.tzset()
except Exception:  # noqa: BLE001
    pass

# Đảm bảo import được các module nội bộ của bot dù tiến trình chạy từ cwd nào.
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import bet_parser
import config
import open_image
import telegram_commands
import telegram_dice
import tzutil
import vietnum
from game import judge_bet
from storage import Storage

# ----------------------- Cấu hình game -----------------------
DEFAULT_BALANCE = 1000
MIN_BET = 2_000
MAX_BET = 50_000_000
HISTORY_LIMIT = 20                 # số ván lưu trong lịch sử mỗi user

# Hệ số lợi nhuận RÒNG khi thắng (không tính vốn trả lại)
# _v79: đổi tỷ lệ trả thưởng thành 1.95 (1 ăn 1.95) cho tất cả cửa.
# Công thức: payout = amount * (PAYOUT + 1) -> 0.95 + 1 = 1.95 (hỗ trợ số thực).
PAYOUT = {"tai": 0.95, "xiu": 0.95, "chan": 0.95, "le": 0.95, "bao": 0.95}

store = Storage(config.DATA_FILE)

# ----------------------- Tài khoản người chơi (/dangky, /dangnhap) -----------------------
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
ACCOUNTS_FILE = os.path.join(BASE_DIR, "accounts.json")


def _load_accounts() -> dict:
    """Đọc file accounts.json (tự tạo rỗng nếu chưa có / file hỏng)."""
    if os.path.exists(ACCOUNTS_FILE):
        try:
            with open(ACCOUNTS_FILE, "r", encoding="utf-8") as f:
                data = json.load(f)
            data.setdefault("accounts", {})
            return data
        except (json.JSONDecodeError, OSError):
            pass
    return {"accounts": {}}


def _save_accounts(data: dict) -> None:
    """Ghi nguyên tử ra accounts.json (ghi file tạm rồi os.replace)."""
    tmp = f"{ACCOUNTS_FILE}.tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
    os.replace(tmp, ACCOUNTS_FILE)


def _hash_password(password: str) -> str:
    """Băm mật khẩu bằng SHA-256 (không lưu mật khẩu gốc)."""
    return hashlib.sha256(password.encode("utf-8")).hexdigest()


def fmt(n: int) -> str:
    """Định dạng số kiểu 1.000.000."""
    return f"{n:,}".replace(",", ".")


def add_history(user: dict, entry: dict):
    user.setdefault("history", []).insert(0, entry)
    del user["history"][HISTORY_LIMIT:]


# v97: LỊCH SỬ CHƠI — mỗi LỆNH CƯỢC 1 bản ghi (khác "history" là kết quả CUỐI phiên).
BET_HISTORY_LIMIT = 60


def add_bet_history(user: dict, entry: dict):
    """Ghi 1 lệnh cược vào lịch sử chơi của user (mới nhất lên đầu, giữ tối đa BET_HISTORY_LIMIT)."""
    user.setdefault("bet_history", []).insert(0, entry)
    del user["bet_history"][BET_HISTORY_LIMIT:]


# ----------------------- Tích hợp Telegram -----------------------
_telegram = telegram_dice.TelegramDice(config.TELEGRAM_BOT_TOKEN, config.TELEGRAM_CHAT_ID)
# Poller tin nhắn/lệnh Telegram — đọc tin nhắn chat thường để nhận cược + lệnh /webadmin, /addcoin.
_tg_cmd_poller = telegram_commands.TelegramCommandPoller(config.TELEGRAM_BOT_TOKEN)


class RoundState:
    """Trạng thái phiên Tài Xỉu hiện tại (mở cược trong lúc đếm ngược)."""

    def __init__(self):
        self.phase = "idle"      # idle | betting | rolling
        self.round_no = 0
        self.bets = {}           # user_id -> [{"bet": "...", "amount": int}, ...]
        self.round_code = ""     # v78: mã phiên 6 chữ số dùng cho tin nhắn xác nhận cược
        self.lock = asyncio.Lock()


_round = RoundState()


# ------------- v78: Tin nhắn RIÊNG (DM) xác nhận đặt cược -------------
_DM_LOG = []  # lưu {uid, msg_id, text} các DM đã gửi — phục vụ kiểm thử/bằng chứng.


def _dm_bet_text(round_no: int, code: str, bets: list, balance: int) -> str:
    """Nội dung tin nhắn RIÊNG xác nhận đặt cược (đúng mẫu người dùng)."""
    # v79: dòng 1 IN ĐẬM toàn bộ; dòng 2 BLOCKQUOTE (cửa + tiền đều in đậm); dòng 3 thường.
    _parts = []
    for b in bets:
        _code = bet_parser.BET_CODE.get(b["bet"], str(b["bet"]).upper())
        _parts.append(f"<b>{_code}</b> <b>{fmt(int(b['amount']))}</b>")
    _line2 = " ".join(_parts)
    return (f"<b>\U0001F949 Đặt thành công phiên XX #{code}</b>\n\n"
            f"<blockquote>{_line2}</blockquote>\n"
            f"Số dư sau khi cược: {fmt(int(balance))}")


def _dm_win_text(round_no: int, door: str, stake: int, payout: int, balance: int) -> str:
    """Nội dung tin nhắn RIÊNG thông báo THẮNG cược (đúng mẫu người dùng).

    ✅ Thắng phiên #160302
    Cược TÀI - 31.040
    Tiền nhận: 60.528
    Số dư mới: 60.528
    """
    _door = bet_parser.BET_LABEL.get(door, str(door).upper())
    return (f"\u2705 Thắng phiên #{round_no}\n"
            f"Cược {_door} - {fmt(int(stake))}\n"
            f"Tiền nhận: {fmt(int(payout))}\n"
            f"Số dư mới: {fmt(int(balance))}")


async def _dm_send_task(uid: str, text: str):
    """Gửi tin nhắn RIÊNG + ghi lại msg_id (im lặng nếu user chưa mở chat riêng)."""
    mid = await _telegram.send_message_to(uid, text)
    _DM_LOG.append({"uid": str(uid), "msg_id": mid, "text": text})
    print(f"\U0001F4E8 [DM] xác nhận đặt cược -> uid={uid} msg_id={mid}")
    return mid


def _fire_dm(uid: str, text: str):
    """Bắn DM bất đồng bộ, KHÔNG làm hỏng luồng đặt cược (nuốt mọi lỗi)."""
    try:
        loop = asyncio.get_running_loop()
        loop.create_task(_dm_send_task(uid, text))
        return
    except RuntimeError:
        pass
    try:
        asyncio.run(_dm_send_task(uid, text))
    except Exception:  # noqa: BLE001
        pass


def _telegram_bet_handler(uid: str, uname: str, text: str) -> str:
    """Xử lý đặt cược từ tin nhắn chat thường trên Telegram (dùng CHUNG parser + state).

    Trả về chuỗi thông báo để bot gửi lại trong chat Telegram.
    """
    if _round.phase != "betting":
        return "⏳ Hiện không có phiên nào đang mở cược. Chờ phiên tiếp theo rồi thử lại."
    try:
        bets = bet_parser.parse_bets(text)
    except ValueError as e:
        return (f"❌ Sai cú pháp: {e}\n"
                "Ví dụ đúng: T 500k X 500k L 500K C 500K\n"
                "(T=Tài, X=Xỉu, C=Chẵn, L=Lẻ, B=Bão; k=nghìn, m=triệu)")
    # Giải từ khoá MAX (cược hết số dư vào 1 cửa) và ALL (chia đều số dư cho các cửa all).
    user = store.get_user(uid)
    balance = int(user.get("balance", 0))
    has_max = any(a == "MAX" for _, a in bets)
    n_all = sum(1 for _, a in bets if a == "ALL")
    _fixed = sum(a for _, a in bets if isinstance(a, int) and a >= 0)
    _avail = max(0, balance - _fixed)
    resolved = []
    for b, a in bets:
        if a == "MAX":
            resolved.append((b, min(_avail, MAX_BET)))
        elif a == "ALL":
            resolved.append((b, (_avail // n_all) if n_all else 0))
        else:
            resolved.append((b, int(a)))
    bets = resolved
    for _, amount in bets:
        if amount < MIN_BET:
            if has_max:
                return "❌ Số dư không đủ."
            if n_all:
                return "❌ Số dư không đủ để chia đều (mỗi cửa tối thiểu 2.000 xu)."
            return f"❌ Cược tối thiểu mỗi cửa là {fmt(MIN_BET)} xu."
        if amount > MAX_BET:
            return f"❌ Cược tối đa mỗi cửa là {fmt(MAX_BET)} xu."
    # BỎ giới hạn 1 lượt cược/phiên — cược nhiều lần trong cùng phiên sẽ CỘNG DỒN.
    total_bet = sum(a for _, a in bets)
    if total_bet > balance:
        return (f"❌ Bạn không đủ xu! Tổng cược {fmt(total_bet)} xu, "
                f"số dư hiện tại: {fmt(balance)} xu.")
    user["balance"] = balance - total_bet
    # Theo dõi tổng tiền ĐÃ CƯỢC (phục vụ điều kiện rút tiền: mốc cược = tiền nạp + số dư tân thủ x3).
    _st = user.setdefault("stats", {})
    _st["wagered"] = int(_st.get("wagered", 0) or 0) + total_bet
    _st["bets"] = int(_st.get("bets", 0) or 0) + 1
    # v97: GHI LỊCH SỬ CHƠI — mỗi lệnh cược 1 bản ghi (phiên, cửa, số tiền, giờ Thái Lan).
    _now = int(time.time())
    for _b, _a in bets:
        add_bet_history(user, {
            "ts": _now,
            "round": int(_round.round_no),
            "code": _round.round_code or str(_round.round_no),
            "door": _b,
            "amount": int(_a),
            "payout": 0,
            "status": "pending",
        })
    store.save()
    # CỘNG DỒN cược trong cùng phiên (đã bỏ giới hạn 1 lượt/phiên).
    _existing = _round.bets.get(uid) or []
    for b, a in bets:
        _hit = next((x for x in _existing if x["bet"] == b), None)
        if _hit:
            _hit["amount"] = int(_hit["amount"]) + int(a)
        else:
            _existing.append({"bet": b, "amount": int(a)})
    _round.bets[uid] = _existing
    # v78: gửi THÊM tin nhắn RIÊNG (DM) xác nhận đặt cược cho CHÍNH người chơi.
    _fire_dm(uid, _dm_bet_text(_round.round_no, _round.round_code, _existing,
                               int(user.get("balance", 0))))
    # Phát hiện CƯỢC XIÊN (cược Tài + Xỉu cùng lúc trong 1 lệnh).
    is_xien = "tai" in {b for b, _ in bets} and "xiu" in {b for b, _ in bets}
    # MẪU MỚI (theo ảnh mẫu): "🎗️ Đặt thành công phiên XX / #N / <CỬA> <số tiền> 🐸 <tên>"
    _name = uname or "Ẩn Danh"
    # v90: dòng 1 IN ĐẬM toàn bộ, gộp số phiên vào cùng dòng: "🥇 Đặt thành công phiên XX #<round_no>"
    _lines = [f"<b>🥇 Đặt thành công phiên XX #{_round.round_no}</b>"]
    if is_xien:
        _lines.append("⚡ <b>CƯỢC XIÊN</b>")
    for _b in _existing:
        _code = bet_parser.BET_CODE.get(_b["bet"], str(_b["bet"]).upper())
        _amt = f"{int(_b['amount']):,}".replace(",", ".")
        _lines.append(f"{_code} {_amt} 🐸 {_name}")
    return "\n".join(_lines)


# Đăng ký hook để tin nhắn cược trên Telegram dùng chung parser.
telegram_commands.set_bet_handler(_telegram_bet_handler)


def _telegram_addcoin_handler(user_id: str, amount: str) -> str:
    """Cộng xu cho người chơi từ lệnh admin /addcoin trên Telegram."""
    try:
        amt = int(str(amount).replace(".", "").replace(",", "").replace("_", ""))
    except (TypeError, ValueError):
        return "❌ Số xu không hợp lệ."
    if amt <= 0:
        return "❌ Số xu phải là số nguyên dương."
    user = store.get_user(str(user_id))
    before = int(user.get("balance", 0))
    user["balance"] = before + amt
    store.save()
    return (f"✅ Đã cộng {fmt(amt)} xu cho {user_id}\n"
            f"💳 Số dư: {fmt(before)} → {fmt(user['balance'])} xu")


# Đăng ký hook cộng xu cho lệnh admin /addcoin trên Telegram.
telegram_commands.set_addcoin_handler(_telegram_addcoin_handler)


def _telegram_balance_handler(uid: str) -> str:
    """Số dư hiện tại của người chơi — phục vụ nút inline 'Tài Khoản' trên /start."""
    user = store.get_user(str(uid))
    return f"{fmt(int(user.get('balance', 0)))} xu"


# Bậc VIP theo TỔNG NẠP: (số VIP, huy hiệu, tên hạng, mốc nạp tối thiểu).
VIP_TIERS = [
    (0, "\U0001F949", "Đồng", 0),
    (1, "\U0001F948", "Bạc", 1_000_000),
    (2, "\U0001F947", "Vàng", 10_000_000),
    (3, "\U0001F48E", "Kim Cương", 100_000_000),
    (4, "\U0001F451", "Hoàng Kim", 1_000_000_000),
]


def _vip_of(deposit: int):
    """Trả về (số VIP, huy hiệu, tên hạng) theo TỔNG NẠP."""
    no, badge, name = VIP_TIERS[0][0], VIP_TIERS[0][1], VIP_TIERS[0][2]
    for n, b, nm, moc in VIP_TIERS:
        if int(deposit) >= moc:
            no, badge, name = n, b, nm
    return no, badge, name


def _telegram_account_handler(uid: str) -> str:
    """Tin nhắn TÀI KHOẢN đầy đủ (Số dư + Cấp VIP + Thống kê) — nút 'Tài Khoản' / lệnh /tk.

    Số liệu lấy THẬT từ data.json (balance, stats.wagered, history) + transactions.json
    (tổng nạp / tổng rút). Ngày hiển thị theo giờ Thái Lan (Asia/Bangkok).
    """
    uid = str(uid)
    user = store.get_user(uid)
    balance = int(user.get("balance", 0) or 0)
    stats = user.get("stats") or {}
    wagered = int(stats.get("wagered", 0) or 0)

    # Tổng nạp / tổng rút từ transactions.json (fallback 'add' nếu chưa có log nạp thật).
    tx_file = os.path.join(BASE_DIR, os.getenv("TX_FILE", "transactions.json").strip() or "transactions.json")
    tx = []
    try:
        with open(tx_file, "r", encoding="utf-8") as f:
            tx = (json.load(f) or {}).get("transactions", []) or []
    except (OSError, json.JSONDecodeError):
        tx = []

    def _sum(kind):
        return sum(int(t.get("amount", 0)) for t in tx
                   if t.get("type") == kind and str(t.get("user_id")) == uid)

    deposit = _sum("deposit")
    if deposit <= 0:
        deposit = _sum("add")
    withdraw = _sum("withdraw")

    # Cược hôm nay / tuần này + chuỗi thắng/thua — tính từ lịch sử cược (mới nhất trước).
    now = tzutil.now()
    start_today = now.replace(hour=0, minute=0, second=0, microsecond=0)
    start_week = start_today - timedelta(days=now.weekday())
    t_today = int(start_today.timestamp())
    t_week = int(start_week.timestamp())
    bet_today = bet_week = 0
    win_streak = lose_streak = 0
    for h in (user.get("history") or []):
        try:
            amt = int(h.get("amount", 0) or 0)
            ts = int(h.get("time", 0) or 0)
        except (TypeError, ValueError):
            continue
        if ts >= t_today:
            bet_today += amt
        if ts >= t_week:
            bet_week += amt
        if h.get("win") is True:
            if lose_streak > 0:
                break
            win_streak += 1
        elif h.get("win") is False:
            if win_streak > 0:
                break
            lose_streak += 1
        else:
            break

    vip_no, vip_badge, vip_name = _vip_of(deposit)
    return (
        "\U0001F9FE <b>TÀI KHOẢN</b>\n"
        f"\U0001F194 ID: <code>{uid}</code>\n"
        f"\U0001F4B0 Số dư: <b>{fmt(balance)}</b>\n"
        f"\U0001F451 Cấp VIP: <b>VIP {vip_no}</b> {vip_badge} <b>({vip_name})</b>\n"
        "\n"
        "\U0001F4C8 <b>THỐNG KÊ</b>\n"
        f"• Cược hôm nay: <b>{fmt(bet_today)}</b>\n"
        f"• Cược tuần này: <b>{fmt(bet_week)}</b>\n"
        f"• Tổng cược: <b>{fmt(wagered)}</b>\n"
        f"• Tổng nạp: <b>{fmt(deposit)}</b>\n"
        f"• Tổng rút: <b>{fmt(withdraw)}</b>\n"
        "\n"
        f"\U0001F5D3\uFE0F <b>{now.strftime('%d/%m/%Y')}</b>\n"
        f"• Chuỗi thắng: <b>{win_streak}</b>\n"
        f"• Chuỗi thua: <b>{lose_streak}</b>"
    )


def _telegram_top_handler() -> str:
    """Bảng ĐUA TOP CƯỢC — xếp hạng theo TỔNG TIỀN CƯỢC (KHÔNG hiển thị số dư).

    v98: đổi tên 'Đua top' -> 'Đua top cược' và BỎ hoàn toàn cột/dòng số dư.
    """
    users = store.data.get("users", {}) or {}
    ranked = sorted(
        users.items(),
        key=lambda kv: int((kv[1].get("stats") or {}).get("wagered", 0) or 0),
        reverse=True,
    )
    ranked = [(uid, u) for uid, u in ranked
              if int((u.get("stats") or {}).get("wagered", 0) or 0) > 0][:10]
    if not ranked:
        return telegram_dice._premiumize("🏆 <b>ĐUA TOP CƯỢC</b>\n\nChưa có ai đặt cược.")
    lines = ["🏆 <b>ĐUA TOP CƯỢC</b>", "<b>Hạng | Người chơi | Tổng cược</b>"]
    for i, (uid, u) in enumerate(ranked, 1):
        name = u.get("username") or uid
        wager = int((u.get("stats") or {}).get("wagered", 0) or 0)
        lines.append(f"{i}. {name} | {fmt(wager)}")
    return telegram_dice._premiumize("\n".join(lines))


# Đăng ký hook cho các nút inline (Số dư / Đua top) trên tin nhắn /start.
telegram_commands.set_balance_handler(_telegram_balance_handler)
telegram_commands.set_account_handler(_telegram_account_handler)
telegram_commands.set_top_handler(_telegram_top_handler)


def _telegram_sd_handler(uid: str) -> str:
    """Lệnh /SD — xem số dư hiện tại + tổng nạp + tổng rút (định dạng dấu chấm nghìn)."""
    uid = str(uid)
    user = store.get_user(uid)
    balance = int(user.get("balance", 0) or 0)
    tx_file = os.path.join(BASE_DIR, os.getenv("TX_FILE", "transactions.json").strip() or "transactions.json")
    deposit = withdraw = 0
    try:
        with open(tx_file, "r", encoding="utf-8") as f:
            tx = (json.load(f) or {}).get("transactions", []) or []
        deposit = sum(int(t.get("amount", 0)) for t in tx
                      if t.get("type") == "deposit" and str(t.get("user_id")) == uid)
        withdraw = sum(int(t.get("amount", 0)) for t in tx
                       if t.get("type") == "withdraw" and str(t.get("user_id")) == uid)
    except (OSError, json.JSONDecodeError):
        pass
    return ("👛 <b>SỐ DƯ</b>\n"
            "┌──────────────────────\n"
            f"│ 💰 Số dư hiện tại: <b>{fmt(balance)} xu</b>\n"
            f"│ 📥 Tổng nạp: <b>{fmt(deposit)} xu</b>\n"
            f"│ 📤 Tổng rút: <b>{fmt(withdraw)} xu</b>\n"
            "└──────────────────────")


# Đăng ký hook lệnh /SD (xem số dư).
telegram_commands.set_sd_handler(_telegram_sd_handler)


def _telegram_withdraw_handler(uid: str, uname: str = "") -> str:
    """Nút "🏦 Rút tiền" — GHI NHẬN yêu cầu rút vào data.json và trả thông báo mới.

    Ghi 1 bản ghi vào user["withdraw_requests"] (giữ tối đa 20) để admin xử lý qua web admin.
    """
    user = store.get_user(str(uid))
    bal = int(user.get("balance", 0))
    reqs = user.setdefault("withdraw_requests", [])
    reqs.insert(0, {
        "ts": int(time.time()),
        "uid": str(uid),
        "uname": uname or str(uid),
        "balance": bal,
        "status": "pending",
    })
    del reqs[20:]
    store.save()
    return ("🏦 <b>YÊU CẦU RÚT TIỀN ĐÃ GHI NHẬN</b>\n"
            "┌──────────────────────\n"
            f"│ 🆔 ID: <code>{uid}</code>\n"
            f"│ 💳 Số dư hiện tại: <b>{fmt(bal)} xu</b>\n"
            "│ 📝 Trạng thái: <b>Chờ admin xử lý</b>\n"
            "└──────────────────────\n"
            "Admin sẽ liên hệ để xác nhận và chuyển tiền. "
            f"\n🏛 Tham gia Room TX: {telegram_commands.ROOM_TX_URL}")


# Đăng ký hook xử lý nút "🏦 Rút tiền" (cả nút trên ảnh lẫn nút ReplyKeyboard).
telegram_commands.set_withdraw_handler(_telegram_withdraw_handler)


def _telegram_bank_get_handler(uid: str):
    """Lấy STK đã liên kết của người dùng (hoặc None)."""
    user = store.get_user(str(uid))
    bank = user.get("bank")
    if isinstance(bank, dict) and bank.get("bank_no"):
        return bank
    return None


def _telegram_bank_link_handler(uid: str, bank_no: str, bank_name: str, bank_owner: str) -> str:
    """LƯU STK (số TK + ngân hàng + chủ TK) vào data.json, gắn với user.

    Hỗ trợ định dạng chuỗi của storage: lưu dict vào user["bank"].
    """
    bank_no = str(bank_no).strip()
    bank_name = str(bank_name).strip()
    bank_owner = str(bank_owner).strip().upper()
    if not bank_no or not bank_name or not bank_owner:
        return "❌ Thiếu thông tin STK (cần số TK + ngân hàng + chủ TK)."
    if not any(ch.isdigit() for ch in bank_no):
        return "❌ Số tài khoản không hợp lệ (phải chứa chữ số)."
    user = store.get_user(str(uid))
    user["bank"] = {
        "bank_no": bank_no,
        "bank_name": bank_name,
        "bank_owner": bank_owner,
        "ts": int(time.time()),
    }
    # Ghi nhớ lựa chọn của người dùng (web admin đọc để hiển thị).
    store.save()
    return ("✅ <b>ĐÃ LIÊN KẾT SỐ TÀI KHOẢN</b>\n"
            "┌──────────────────────\n"
            f"│ 🏦 Ngân hàng: <b>{bank_name}</b>\n"
            f"│ 🔢 Số tài khoản: <code>{bank_no}</code>\n"
            f"│ 👤 Chủ tài khoản: <b>{bank_owner}</b>\n"
            "└──────────────────────\n"
            "👉 Bấm nút <b>🏦 Rút tiền</b> để tạo yêu cầu rút về STK này.")


def _telegram_withdraw_confirm_handler(uid: str, uname: str = "") -> str:
    """Nút "✅ Xác nhận rút tiền" — CHỈ cho rút khi đã có STK; tạo yêu cầu rút KÈM STK."""
    user = store.get_user(str(uid))
    bank = user.get("bank")
    if not (isinstance(bank, dict) and bank.get("bank_no")):
        # Chưa liên kết STK → hướng dẫn (không tạo yêu cầu).
        return telegram_commands.build_withdraw_reply(str(uid))
    bal = int(user.get("balance", 0))
    reqs = user.setdefault("withdraw_requests", [])
    reqs.insert(0, {
        "ts": int(time.time()),
        "uid": str(uid),
        "uname": uname or str(uid),
        "balance": bal,
        "status": "pending",
        "bank_no": bank.get("bank_no", ""),
        "bank_name": bank.get("bank_name", ""),
        "bank_owner": bank.get("bank_owner", ""),
    })
    del reqs[20:]
    store.save()
    return ("🏦 <b>YÊU CẦU RÚT TIỀN ĐÃ GHI NHẬN</b>\n"
            "┌──────────────────────\n"
            f"│ 🆔 ID: <code>{uid}</code>\n"
            f"│ 🏦 Ngân hàng: <b>{bank.get('bank_name', '')}</b>\n"
            f"│ 🔢 Số tài khoản: <code>{bank.get('bank_no', '')}</code>\n"
            f"│ 👤 Chủ tài khoản: <b>{bank.get('bank_owner', '')}</b>\n"
            f"│ 💳 Số dư hiện tại: <b>{fmt(bal)} xu</b>\n"
            "│ 📝 Trạng thái: <b>Chờ admin xử lý</b>\n"
            "└──────────────────────\n"
            "Admin sẽ liên hệ để xác nhận và chuyển tiền về STK trên. "
            f"\n🏛 Tham gia Room TX: {telegram_commands.ROOM_TX_URL}")


# Đăng ký hook STK + xác nhận rút tiền (bot.py là nguồn ghi data.json).
telegram_commands.set_bank_get_handler(_telegram_bank_get_handler)
telegram_commands.set_bank_link_handler(_telegram_bank_link_handler)
telegram_commands.set_withdraw_confirm_handler(_telegram_withdraw_confirm_handler)


def _telegram_stats_handler(uid: str) -> dict:
    """Số liệu ĐỘNG của người dùng cho tin nhắn RÚT TIỀN.

      - deposit : tổng tiền đã NẠP (transactions.json, type=deposit; fallback = tổng 'add')
      - wagered : tổng tiền đã CƯỢC (lấy từ stats.wagered của user)
      - balance : số dư hiện tại
    """
    uid = str(uid)
    user = store.get_user(uid)
    wagered = int((user.get("stats") or {}).get("wagered", 0) or 0)
    balance = int(user.get("balance", 0) or 0)
    tx_file = os.path.join(BASE_DIR, os.getenv("TX_FILE", "transactions.json").strip() or "transactions.json")
    tx = []
    try:
        with open(tx_file, "r", encoding="utf-8") as f:
            tx = (json.load(f) or {}).get("transactions", []) or []
    except (OSError, json.JSONDecodeError):
        tx = []

    def _sum(kind):
        return sum(int(t.get("amount", 0)) for t in tx
                   if t.get("type") == kind and str(t.get("user_id")) == uid)

    deposit = _sum("deposit")
    if deposit <= 0:
        # Fallback: chưa có log nạp thật → dùng tổng /addcoin đã cộng cho user này.
        deposit = _sum("add")
    return {"deposit": deposit, "wagered": wagered, "balance": balance}


telegram_commands.set_stats_handler(_telegram_stats_handler)


def _telegram_rut_handler(uid: str, uname: str = "", arg: str = ""):
    """Xử lý lệnh /rut [số tiền] và /rut all — rút tiền về STK đã liên kết.

      - Chưa liên kết STK   → yêu cầu liên kết trước.
      - Chưa đủ điều kiện   → báo chưa đủ (+ số còn thiếu).
      - Hợp lệ             → trừ số dư, trừ phí 1%, ghi yêu cầu rút KÈM STK vào data.json.
    """
    uid = str(uid)
    user = store.get_user(uid)
    bank = user.get("bank")
    if not (isinstance(bank, dict) and bank.get("bank_no")):
        # Chưa liên kết STK → trả về (text, inline keyboard) yêu cầu liên kết.
        return telegram_commands.build_withdraw_reply(uid)

    stats = _telegram_stats_handler(uid)
    deposit = int(stats.get("deposit", 0) or 0)
    wagered = int(stats.get("wagered", 0) or 0)
    moc = deposit + telegram_commands.NEWBIE_RESERVED * telegram_commands.WAGER_MULT
    if wagered < moc:
        return ("❌ <b>CHƯA ĐỦ ĐIỀU KIỆN RÚT</b>\n"
                "┌──────────────────────\n"
                f"│ 📋 Mốc cược cần đủ: <code>{telegram_commands._fmt_vn(moc)}</code>\n"
                f"│ ✅ Hiện đã cược: <code>{telegram_commands._fmt_vn(wagered)}</code>\n"
                f"│ ⏳ Còn thiếu: <code>{telegram_commands._fmt_vn(max(0, moc - wagered))}</code>\n"
                "└──────────────────────\n"
                "Hãy cược thêm rồi thử lại.")

    # Lấy lại user MỚI NHẤT từ store: _telegram_stats_handler() ở trên đã gọi
    # store.get_user() (merge → thay self.data) nên biến `user` cũ đã mất hiệu lực;
    # ghi vào object cũ thì store.save() sẽ KHÔNG lưu được số dư đã trừ.
    user = store.get_user(uid)
    bank = user.get("bank") or bank
    args = (arg or "").strip().lower()
    balance = int(user.get("balance", 0))
    max_net = min(telegram_commands.WITHDRAW_MAX, balance)
    if args in ("all", "max", "hết", "het", "tối đa", "toida"):
        amount = max_net
    elif args:
        try:
            amount = int(args.replace(".", "").replace(",", "").replace("_", ""))
        except ValueError:
            return ("❌ Số tiền không hợp lệ.\n"
                    "Cú pháp: <code>/rut 50000</code> hoặc <code>/rut all</code>")
    else:
        return ("📋 <b>CÚ PHÁP RÚT TIỀN</b>\n"
                "• <code>/rut 50000</code> — rút 50k\n"
                "• <code>/rut all</code> — rút tối đa phần khả dụng")

    if amount < telegram_commands.WITHDRAW_MIN:
        return (f"❌ Rút tối thiểu <b>{telegram_commands._fmt_vn(telegram_commands.WITHDRAW_MIN)} xu</b> mỗi lần.")
    if amount > telegram_commands.WITHDRAW_MAX:
        return (f"❌ Rút tối đa <b>{telegram_commands._fmt_vn(telegram_commands.WITHDRAW_MAX)} xu</b> mỗi lần.")
    if amount > balance:
        return ("❌ Không đủ số dư khả dụng!\n"
                f"💳 Số dư hiện tại: <b>{fmt(balance)} xu</b>, cần rút: <b>{fmt(amount)} xu</b>.")

    fee = int(round(amount * telegram_commands.WITHDRAW_FEE_PCT / 100.0))
    net = amount - fee
    order_no = str(random.randint(100000000, 999999999))
    user["balance"] = balance - amount
    reqs = user.setdefault("withdraw_requests", [])
    reqs.insert(0, {
        "ts": int(time.time()),
        "uid": uid,
        "uname": uname or uid,
        "order_no": order_no,
        "amount": amount,
        "fee": fee,
        "net": net,
        "balance": user["balance"],
        "status": "pending",
        "deducted": True,  # /rut ĐÃ trừ tiền lúc tạo đơn → web admin KHÔNG trừ lại khi duyệt
        "bank_no": bank.get("bank_no", ""),
        "bank_name": bank.get("bank_name", ""),
        "bank_owner": bank.get("bank_owner", ""),
    })
    del reqs[20:]
    store.save()
    # MẪU MỚI: "✅ Đã tạo đơn rút <mã> ... Đơn đang chờ admin duyệt."
    return ("✅ Đã tạo đơn rút <code>{code}</code>\n\n"
            "- Số tiền rút: <b>{amt}</b>\n"
            "- Phí {pct:g}%: <b>{fee}</b>\n"
            "- Số dư còn lại: <b>{bal}</b>\n"
            "Đơn đang chờ admin duyệt.").format(
                code=order_no, amt=fmt(amount),
                pct=telegram_commands.WITHDRAW_FEE_PCT, fee=fmt(fee),
                bal=fmt(user["balance"]))


# Đăng ký hook số liệu + rút tiền (/rut) cho poller lệnh Telegram.
telegram_commands.set_rut_handler(_telegram_rut_handler)


def _parse_amount(arg: str):
    """Phân tích số tiền từ chuỗi (hỗ trợ k/K=nghìn, m/M=triệu). Trả về int hoặc None."""
    s = (arg or "").strip().lower().replace(".", "").replace(",", "").replace("_", "").replace(" ", "")
    if not s:
        return None
    mult = 1
    if s.endswith("k"):
        mult, s = 1_000, s[:-1]
    elif s.endswith("m"):
        mult, s = 1_000_000, s[:-1]
    try:
        return int(float(s) * mult)
    except ValueError:
        return None


def _telegram_deposit_handler(uid: str, uname: str = "", amount=None):
    """Tạo YÊU CẦU NẠP (pending) + trả (caption, markup, photo_url) kèm QR VietQR.

    Dùng cho cả nút mệnh giá (callback dep:<amount>) lẫn lệnh /nap <số tiền>.
    """
    uid = str(uid)
    amt = amount if isinstance(amount, int) else _parse_amount(str(amount))
    if not amt or amt < telegram_commands.DEPOSIT_MIN:
        # Chưa có / sai số tiền → hiện tin nhắn CHỌN MỆNH GIÁ + 10 nút.
        return telegram_commands.build_deposit_choose_reply()
    if amt > telegram_commands.DEPOSIT_MAX:
        amt = telegram_commands.DEPOSIT_MAX
    # Mã nội dung NGẪU NHIÊN mỗi lần (không dùng lại).
    code = "GUI ANH NHE " + "".join(random.choices(string.ascii_uppercase + string.digits, k=6))
    user = store.get_user(uid)
    reqs = user.setdefault("deposit_requests", [])
    reqs.insert(0, {
        "ts": int(time.time()),
        "uid": uid,
        "uname": uname or uid,
        "amount": int(amt),
        "content": code,
        "status": "pending",
    })
    del reqs[20:]
    store.save()
    return telegram_commands.build_deposit_info(int(amt), code)


def _telegram_nap_handler(uid: str, uname: str = "", arg: str = ""):
    """Lệnh /nap [số tiền] — tạo YÊU CẦU NẠP (pending) + gửi QR chuyển khoản.

    Không kèm số tiền → hiện tin nhắn CHỌN MỆNH GIÁ + 10 nút mệnh giá.
    """
    amount = _parse_amount(arg)
    if not amount or amount <= 0:
        return telegram_commands.build_deposit_choose_reply()
    return _telegram_deposit_handler(uid, uname, amount)


# Đăng ký hook tạo yêu cầu nạp (/nap) + nút mệnh giá (QR) cho poller lệnh Telegram.
telegram_commands.set_nap_handler(_telegram_nap_handler)
telegram_commands.set_deposit_handler(_telegram_deposit_handler)


# ----------------------- v94: LỊCH SỬ NẠP / RÚT — BẢNG + PHÂN TRANG -----------------------
_STATUS_LABEL = {
    "pending": "⏳ Chờ duyệt",
    "approved": "✅ Đã xử lí",
    "rejected": "❌ Từ chối",
}
HISTORY_PAGE_SIZE = 10  # số dòng mỗi trang


def _history_game_code(r: dict) -> str:
    """Mã giao dịch hiển thị ở cột 'Game' (order_no / deposit_code / code / id / ts)."""
    for k in ("order_no", "deposit_code", "code", "id"):
        v = r.get(k)
        if v:
            return str(v)
    ts = int(r.get("ts", 0) or 0)
    return str(ts) if ts else "—"


def _telegram_history_handler(uid: str, kind: str = "deposit", page: int = 1) -> str:
    """Hiển thị LỊCH SỬ NẠP hoặc RÚT của người chơi dạng BẢNG + PHÂN TRANG.

    Cột: Thời gian | Game | Số tiền | Trạng thái
    kind = "deposit"  -> user["deposit_requests"]
    kind = "withdraw" -> user["withdraw_requests"]
    """
    uid = str(uid)
    user = store.get_user(uid)
    is_dep = (kind != "withdraw")
    key = "deposit_requests" if is_dep else "withdraw_requests"
    reqs = list(user.get(key) or [])
    title = "📈 <b>LỊCH SỬ NẠP</b>" if is_dep else "⌛ <b>LỊCH SỬ RÚT</b>"
    if not reqs:
        return telegram_dice._premiumize(
            f"{title}\n\n"
            + ("Chưa có giao dịch nạp nào." if is_dep else "Chưa có giao dịch rút nào."))
    # Mới nhất lên đầu.
    reqs = sorted(reqs, key=lambda r: int(r.get("ts", 0) or 0), reverse=True)
    total = len(reqs)
    size = HISTORY_PAGE_SIZE
    last_page = max(1, (total + size - 1) // size)
    try:
        page = int(page)
    except Exception:  # noqa: BLE001
        page = 1
    page = min(max(1, page), last_page)
    start = (page - 1) * size
    chunk = reqs[start:start + size]
    lines = [title, "<b>Thời gian | Game | Số tiền | Trạng thái</b>"]
    for i, r in enumerate(chunk, start=start + 1):
        ts = int(r.get("ts", 0) or 0)
        when = time.strftime("%H:%M:%S %d/%m/%Y", time.localtime(ts)) if ts else "—"
        game = _history_game_code(r)
        amt = fmt(int(r.get("amount", 0) or 0))
        st = _STATUS_LABEL.get(r.get("status"), r.get("status") or "—")
        lines.append(f"{i}. {when} | {game} | {amt} | {st}")
    lines.append(f"Trang {page} | Hiển thị {start + 1}-{start + len(chunk)} | Trang cuối {last_page}")
    # v95: boc PREMIUM emoji (<tg-emoji>) cho TOAN BO tin lich su nap/rut.
    return telegram_dice._premiumize("\n".join(lines))


# Đăng ký hook lịch sử nạp/rút cho 2 nút inline "LS nạp" / "LS rút".
telegram_commands.set_history_handler(_telegram_history_handler)


# ----------------------- v97: LỊCH SỬ ROOM (phiên) + LỊCH SỬ CHƠI (cược) — BẢNG + PHÂN TRANG -----------------------
_ROUND_RESULT_LABEL = {"tai": "TÀI", "xiu": "XỈU", "bao": "BÃO"}
_BET_STATUS = {"win": "✅ Thắng", "lose": "❌ Thua", "pending": "⏳ Chờ", "refund": "↩️ Hoàn"}


def _telegram_room_history_handler(page: int = 1) -> str:
    """'LS ROOM TX' — bảng lịch sử các PHIÊN thật từ round_history.json.

    Cột: # | Thời gian | Kết quả | Tổng điểm | Tổng cược (giờ Thái Lan).
    """
    hist = list(telegram_dice.load_round_history() or [])
    hist.sort(key=lambda h: int(h.get("time", 0) or 0), reverse=True)
    title = "🎮 <b>LỊCH SỬ ROOM TX</b>"
    if not hist:
        return telegram_dice._premiumize(f"{title}\n\nChưa có phiên nào.")
    total = len(hist)
    size = HISTORY_PAGE_SIZE
    last_page = max(1, (total + size - 1) // size)
    try:
        page = int(page)
    except Exception:  # noqa: BLE001
        page = 1
    page = min(max(1, page), last_page)
    start = (page - 1) * size
    chunk = hist[start:start + size]
    lines = [title, "<b># | Thời gian | Kết quả | Tổng điểm | Tổng cược</b>"]
    for i, h in enumerate(chunk, start=start + 1):
        ts = int(h.get("time", 0) or 0)
        when = time.strftime("%H:%M:%S %d/%m/%Y", time.localtime(ts)) if ts else "—"
        res = _ROUND_RESULT_LABEL.get(str(h.get("result")), str(h.get("result") or "—").upper())
        total_pt = int(h.get("total", 0) or 0)
        wager = int(h.get("wager", 0) or 0)
        lines.append(f"{i}. {when} | {res} | {total_pt} | {fmt(wager)}")
    lines.append(f"Trang {page} | Hiển thị {start + 1}-{start + len(chunk)} | Trang cuối {last_page}")
    return telegram_dice._premiumize("\n".join(lines))


def _telegram_bet_history_handler(uid: str, page: int = 1) -> str:
    """'LS CHƠI' — bảng lịch sử CƯỢC của user từ user['bet_history'].

    Cột: # | Thời gian | Phiên | Cửa | Số tiền | Kết quả | Tiền nhận (giờ Thái Lan).
    """
    uid = str(uid)
    user = store.get_user(uid)
    rows = list(user.get("bet_history") or [])
    title = "🕹️ <b>LỊCH SỬ CHƠI</b>"
    if not rows:
        return telegram_dice._premiumize(f"{title}\n\nChưa có lệnh cược nào.")
    rows.sort(key=lambda r: int(r.get("ts", 0) or 0), reverse=True)
    total = len(rows)
    size = HISTORY_PAGE_SIZE
    last_page = max(1, (total + size - 1) // size)
    try:
        page = int(page)
    except Exception:  # noqa: BLE001
        page = 1
    page = min(max(1, page), last_page)
    start = (page - 1) * size
    chunk = rows[start:start + size]
    lines = [title, "<b># | Thời gian | Phiên | Cửa | Số tiền | Kết quả | Tiền nhận</b>"]
    for i, r in enumerate(chunk, start=start + 1):
        ts = int(r.get("ts", 0) or 0)
        when = time.strftime("%H:%M:%S %d/%m/%Y", time.localtime(ts)) if ts else "—"
        rnd = r.get("code") or r.get("round") or "—"
        door = bet_parser.BET_LABEL.get(r.get("door"), str(r.get("door") or "—").upper())
        amt = fmt(int(r.get("amount", 0) or 0))
        st = _BET_STATUS.get(r.get("status"), r.get("status") or "—")
        recv = fmt(int(r.get("payout", 0) or 0)) if r.get("status") == "win" else "-"
        lines.append(f"{i}. {when} | {rnd} | {door} | {amt} | {st} | {recv}")
    lines.append(f"Trang {page} | Hiển thị {start + 1}-{start + len(chunk)} | Trang cuối {last_page}")
    return telegram_dice._premiumize("\n".join(lines))


def _settle_bet_history(bets: dict, round_no: int, total: int, result: str):
    """Ghi KẾT QUẢ thắng/thua vào lịch sử chơi của mọi người đã cược ở phiên vừa xong."""
    changed = False
    for uid in list(bets.keys()):
        u = store.get_user(uid)
        for rec in (u.get("bet_history") or []):
            if int(rec.get("round", -1) or -1) == int(round_no) and rec.get("status") == "pending":
                door = rec.get("door")
                amt = int(rec.get("amount", 0) or 0)
                if judge_bet(door, total, result):
                    rec["status"] = "win"
                    rec["payout"] = int(round(amt * (PAYOUT.get(door, 1) + 1)))
                else:
                    rec["status"] = "lose"
                    rec["payout"] = 0
                changed = True
    if changed:
        store.save()


telegram_commands.set_room_history_handler(_telegram_room_history_handler)
telegram_commands.set_bet_history_handler(_telegram_bet_history_handler)


# ----------------------- Vòng lặp Tài Xỉu: ĐẾM NGƯỢC → TUNG TELEGRAM → GỬI KẾT QUẢ -----------------------
BET_WINDOW_OPEN = 40  # mở cược khi còn 40s
BET_WINDOW_LOCK = 20  # chốt cược khi còn 20s


def _countdown_text(round_no: int, bets=None, seconds: int = BET_WINDOW_OPEN) -> str:
    """Nội dung tin nhắn ĐẾM NGƯỢC (TEXT) đăng lên nhóm Telegram.

    Định dạng mẫu (tất cả IN ĐẬM):
        Còn 40 giây phiên #80307
        🔵 TÀI: 0
        🔴 XỈU: 0

        ⚪️ CHẴN: 0
        ⚫️ LẺ: 0
    """
    sums = {"tai": 0, "xiu": 0, "chan": 0, "le": 0, "bao": 0}
    if bets:
        for _ubets in bets.values():
            for b in _ubets:
                k = b.get("bet")
                if k in sums:
                    sums[k] += int(b.get("amount", 0) or 0)
    return (
        f"<b>Còn {seconds} giây phiên #{round_no}</b>\n"
        f"<b>🔵 TÀI: {telegram_commands._fmt_vn(sums['tai'])}</b>\n"
        f"<b>🔴 XỈU: {telegram_commands._fmt_vn(sums['xiu'])}</b>\n"
        f"\n"
        f"<b>⚪️ CHẴN: {telegram_commands._fmt_vn(sums['chan'])}</b>\n"
        f"<b>⚫️ LẺ: {telegram_commands._fmt_vn(sums['le'])}</b>"
    )


def _bet_time_up_text(round_no: int, bets=None) -> str:
    """Nội dung tin nhắn HẾT THỜI GIAN ĐẶT CƯỢC (gửi ngay sau mốc đếm ngược cuối).

    Định dạng mẫu (tất cả IN ĐẬM, có dòng trống giữa nhóm TÀI/XỈU và CHẴN/LẺ):
        Hết thời gian đặt cược phiên #80307
        🔵 TÀI: 58.784
        🔴 XỈU: 0

        ⚪️ CHẴN: 0
        ⚫️ LẺ: 0
    """
    sums = {"tai": 0, "xiu": 0, "chan": 0, "le": 0, "bao": 0}
    if bets:
        for _ubets in bets.values():
            for b in _ubets:
                k = b.get("bet")
                if k in sums:
                    sums[k] += int(b.get("amount", 0) or 0)
    return telegram_dice._premiumize(
        f"<b>Hết thời gian đặt cược phiên #{round_no}</b>\n"
        f"<b>🔵 TÀI: {telegram_commands._fmt_vn(sums['tai'])}</b>\n"
        f"<b>🔴 XỈU: {telegram_commands._fmt_vn(sums['xiu'])}</b>\n"
        f"\n"
        f"<b>⚪️ CHẴN: {telegram_commands._fmt_vn(sums['chan'])}</b>\n"
        f"<b>⚫️ LẺ: {telegram_commands._fmt_vn(sums['le'])}</b>"
    )


async def _run_round():
    """1 phiên đầy đủ: đếm ngược (mở cược) → khóa → tung Telegram → gửi kết quả → trả thưởng."""
    async with _round.lock:
        _round.round_no += 1
        _round.bets = {}
        _round.phase = "betting"
        round_no = _round.round_no
        # v78: mã phiên = số phiên — dùng cho tin nhắn xác nhận đặt cược.
        _round.round_code = str(round_no)

        interval = max(5, int(config.ROUND_INTERVAL))

        # --- Giai đoạn 1: ĐẾM NGƯỢC — ĐÚNG 2 TIN TEXT (mốc 40s và mốc 20s), KHÔNG đếm từng giây, KHÔNG edit ---
        # Tin #1 tại mốc 40s (bắt đầu phiên).
        if _telegram.enabled:
            try:
                await _telegram.send_message(
                    _countdown_text(round_no, _round.bets, BET_WINDOW_OPEN))
                print(f"📢 Đã gửi tin countdown #1 (40s) phiên #{round_no} lên nhóm Telegram.")
            except Exception as e:  # noqa: BLE001
                print(f"⚠️ Không gửi được tin countdown #1 Telegram: {e}")
        else:
            print(f"ℹ️ Phiên #{round_no}: Telegram TẮT — chỉ log đếm ngược.")

        remaining = interval
        sent_lock_msg = False
        while remaining > 0:
            await asyncio.sleep(1)
            remaining -= 1
            # Tin #2 tại mốc 20s (chốt cược) — gửi ĐÚNG 1 lần.
            if (not sent_lock_msg) and remaining <= BET_WINDOW_LOCK:
                sent_lock_msg = True
                if _telegram.enabled:
                    try:
                        await _telegram.send_message(
                            _countdown_text(round_no, _round.bets, BET_WINDOW_LOCK))
                        print(f"📢 Đã gửi tin countdown #2 (20s) phiên #{round_no} lên nhóm Telegram.")
                    except Exception as e:  # noqa: BLE001
                        print(f"⚠️ Không gửi được tin countdown #2 Telegram: {e}")
            print(f"⏳ Phiên #{round_no}: còn {remaining}s — {len(_round.bets)} người đã cược.")

        # --- Giai đoạn 1b: THÔNG BÁO HẾT THỜI GIAN ĐẶT CƯỢC (ngay sau mốc đếm ngược cuối, trước khi tung xúc xắc) ---
        if _telegram.enabled:
            try:
                await _telegram.send_message(_bet_time_up_text(round_no, _round.bets))
                print(f"📢 Đã gửi tin HẾT THỜI GIAN ĐẶT CƯỢC phiên #{round_no} lên nhóm Telegram.")
            except Exception as e:  # noqa: BLE001
                print(f"⚠️ Không gửi được tin hết thời gian đặt cược Telegram: {e}")

        # --- Giai đoạn 2: KHÓA CƯỢC (chốt cược) — KHÔNG gửi thêm tin, tin #2 (20s) đã báo chốt ---
        _round.phase = "rolling"
        bets = dict(_round.bets)

        # --- Giai đoạn 3: TUNG XÚC XẮC BÊN TELEGRAM ---
        source = "telegram"
        dice = None
        if _telegram.enabled:
            try:
                dice = await _telegram.roll_three()
            except Exception as e:  # noqa: BLE001
                print(f"⚠️ Không tung được xúc xắc bên Telegram: {e} — dùng FALLBACK.")
                dice = None
        if not dice:
            dice = telegram_dice.random_dice()
            source = "fallback"

        total, result = telegram_dice.classify(dice)

        # --- Giai đoạn 4: LẤY ẢNH (chụp màn hình thật → fallback render Pillow) ---
        png = telegram_dice.get_round_image(dice, total, result, source=source)

        # --- Giai đoạn 5: TRẢ THƯỞNG cho người đã cược ---
        winners, losers, total_paid = [], [], 0
        for uid, user_bets in bets.items():
            user = store.get_user(uid)
            for b in user_bets:
                if judge_bet(b["bet"], total, result):
                    payout = int(round(b["amount"] * (PAYOUT.get(b["bet"], 1) + 1)))
                    user["balance"] += payout
                    total_paid += payout
                    winners.append((uid, b, payout))
                    # v79: gửi DM thông báo THẮNG cho người chơi (bất đồng bộ, không chặn vòng).
                    _fire_dm(uid, _dm_win_text(round_no, b["bet"], int(b["amount"]),
                                               payout, int(user.get("balance", 0))))
                else:
                    losers.append((uid, b))
        if bets:
            store.save()

        # --- Giai đoạn 5b: LƯU LỊCH SỬ PHIÊN + GỬI TIN NHẮN KẾT QUẢ VÀO NHÓM TELEGRAM ---
        _wager_total = sum(int(b["amount"]) for _ub in bets.values() for b in _ub)
        history = telegram_dice.append_round_history(total, result, wager=_wager_total)
        _settle_bet_history(bets, round_no, total, result)
        if _telegram.enabled and source == "telegram":
            try:
                win_list = [(str(uid), payout) for uid, b, payout in winners]
                lose_list = [(str(uid), b["amount"]) for uid, b in losers]
                jackpot = telegram_dice.get_jackpot()
                sent = await _telegram.send_result_message(
                    dice, total, result, round_no=round_no,
                    winners=win_list, losers=lose_list, total_paid=total_paid,
                    jackpot=jackpot, history=history)
                if sent:
                    print(f"📨 Đã gửi tin nhắn kết quả vào nhóm Telegram: "
                          f"🎯 Kết quả Phiên #{round_no} — {dice} ➔ ({total}) "
                          f"{telegram_dice.RESULT_LABEL.get(result, result)}")
                else:
                    print("⚠️ Không gửi được tin nhắn kết quả vào nhóm Telegram.")
            except Exception as e:  # noqa: BLE001
                print(f"⚠️ Lỗi gửi tin nhắn kết quả Telegram: {e}")

        # --- Giai đoạn 6: GỬI ẢNH KẾT QUẢ VỀ NHÓM TELEGRAM ---
        if _telegram.enabled and png:
            try:
                caption = (f"🎲 Phiên #{round_no}: {dice} ➔ {total} "
                           f"({telegram_dice.RESULT_LABEL.get(result, result)} "
                           f"{telegram_dice.RESULT_EMOJI.get(result, '')})")
                ok = await _telegram.send_photo(png, caption=caption)
                if ok:
                    print(f"🖼️ Đã gửi ảnh kết quả phiên #{round_no} về nhóm Telegram.")
            except Exception as e:  # noqa: BLE001
                print(f"⚠️ Không gửi được ảnh kết quả về Telegram: {e}")

        print(f"✅ Kết thúc phiên #{round_no}: {dice} → {total} ({result}) "
              f"[nguồn: {source}] — {len(bets)} người cược, trả {total_paid} xu.")

        _round.phase = "idle"


async def _round_loop():
    """Vòng lặp vô hạn: mỗi phiên gồm đếm ngược ROUND_INTERVAL giây rồi tung xúc xắc."""
    print(f"🔁 Bắt đầu vòng lặp Tài Xỉu mỗi {config.ROUND_INTERVAL}s "
          f"(Telegram: {'BẬT' if _telegram.enabled else 'TẮT — dùng fallback'}).")
    while True:
        try:
            await _run_round()
        except Exception as e:  # noqa: BLE001
            print(f"⚠️ Lỗi trong phiên Tài Xỉu: {e}")
        await asyncio.sleep(2)


def _token_looks_valid(tok: str) -> bool:
    """Token bot Telegram hợp lệ có dạng '<digits>:<secret>'."""
    return bool(tok) and ":" in tok and tok.split(":", 1)[0].isdigit()


async def _amain():
    if not config.TELEGRAM_BOT_TOKEN:
        raise SystemExit("❌ Thiếu TELEGRAM_BOT_TOKEN. Hãy tạo file .env (xem .env.example).")
    if not _token_looks_valid(config.TELEGRAM_BOT_TOKEN):
        print("⚠️ CẢNH BÁO: TELEGRAM_BOT_TOKEN không đúng định dạng '<số>:<chuỗi>'.")
    if not config.TELEGRAM_CHAT_ID:
        print("⚠️ CẢNH BÁO: Chưa cấu hình TELEGRAM_CHAT_ID — bot sẽ không gửi được vào nhóm.")

    print("=" * 60)
    print("  BOT TÀI XỈU — CHỈ CHẠY TELEGRAM (không Discord)")
    print(f"  Dữ liệu: {store.path}")
    print(f"  Chu kỳ phiên: {config.ROUND_INTERVAL}s")
    print("=" * 60)

    # Khởi động poller tin nhắn Telegram (nhận cược chat thường + lệnh /webadmin, /addcoin).
    _tg_cmd_poller.start()

    # Thông báo bot online vào nhóm Telegram (đồng thời là tín hiệu kiểm tra sống).
    if _telegram.enabled:
        try:
            await _telegram.send_message("🤖 <b>Bot Tài Xỉu (Telegram)</b> đã online. "
                                         "Gõ tin nhắn để đặt cược, vd: <code>T 200k X 200k</code>")
        except Exception as e:  # noqa: BLE001
            print(f"⚠️ Không gửi được thông báo online: {e}")

    await _round_loop()


if __name__ == "__main__":
    try:
        asyncio.run(_amain())
    except KeyboardInterrupt:
        print("👋 Đã dừng bot.")