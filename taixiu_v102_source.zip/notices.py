"""
notices.py — Mẫu THÔNG BÁO NẠP / RÚT (bám sát 3 ảnh mẫu của user).
================================================================================
Dùng CHUNG cho bot.py và webadmin.py để tin nhắn thông báo nạp/rút luôn ĐỒNG NHẤT.

Mẫu NẠP (ảnh mẫu):
    ET99 - THÔNG BÁO 🎉 Thông Báo
    🐸🔴 Người chơi ID: *****86761
    - Nạp bank thành công: 50.000
    🎉 Khuyến mãi nạp 2%: +1.000
    20:14

Mẫu RÚT (ảnh mẫu):
    ET99 - THÔNG BÁO 🎉 Thông Báo
    🎉 🧧 [BOT] Người chơi ID: *****07548
    - Rút Bank thành công: 200.000
    20:23
"""
import time

import tzutil  # noqa: E402 — múi giờ chuẩn Asia/Bangkok (UTC+7)

# Tiêu đề thông báo (brand ET99 — giữ nguyên quy ước đổi tên ET88 -> ET99).
NOTICE_HEADER = "ET99 - THÔNG BÁO"
# Khuyến mãi nạp (%).
DEPOSIT_PROMO_PCT = 2.0


def _fmt_vn(n) -> str:
    """Định dạng số kiểu 1.000.000."""
    try:
        return f"{int(n):,}".replace(",", ".")
    except (TypeError, ValueError):
        return str(n)


def _mask_uid(uid) -> str:
    """Che ID người chơi: ***** + 5 số cuối (đúng mẫu ảnh)."""
    s = str(uid)
    return "*****" + (s[-5:] if len(s) >= 5 else s)


def _hhmm(ts=None) -> str:
    """Giờ:phút theo giờ Việt Nam (UTC+7)."""
    t = time.gmtime((int(ts) if ts else int(time.time())) + 7 * 3600)
    return f"{t.tm_hour:02d}:{t.tm_min:02d}"


def format_deposit_notice(uid, amount, promo=None, ts=None) -> str:
    """THÔNG BÁO NẠP TIỀN — đúng mẫu ảnh (HTML, in đậm số tiền)."""
    amt = int(amount or 0)
    if promo is None:
        promo = int(round(amt * DEPOSIT_PROMO_PCT / 100.0))
    return (
        f"<b>{NOTICE_HEADER}</b> 🎉 Thông Báo\n"
        f"🐸🔴 Người chơi ID: {_mask_uid(uid)}\n"
        f"- Nạp bank thành công: <b>{_fmt_vn(amt)}</b>\n"
        f"🎉 Khuyến mãi <b>nạp</b> {DEPOSIT_PROMO_PCT:g}%: <b>+{_fmt_vn(promo)}</b>\n"
        f"{_hhmm(ts)}"
    )


def build_deposit_approved_msg(amount, promo, need, after, code) -> str:
    """MẪU DUYỆT NẠP TIỀN (theo yêu cầu) — số tiền + KM 2% + cần cược để rút
    + số dư hiện tại + mã đối soát. Số liệu ĐỘNG theo từng giao dịch."""
    return (
        f"✅ <b>Nạp tiền thành công {_fmt_vn(amount)}</b>\n\n"
        f"🎉 Khuyến mãi thêm 2%: <b>+{_fmt_vn(promo)}</b>\n"
        f"🎯 Cần cược để rút: <b>{_fmt_vn(need)}</b>\n\n"
        f"- Số dư hiện tại: <b>{_fmt_vn(after)}</b>\n"
        f"🧾 Mã đối soát: <code>{code}</code>"
    )


def format_withdraw_notice(uid, amount, ts=None) -> str:
    """THÔNG BÁO RÚT TIỀN — đúng mẫu ảnh (HTML, in đậm số tiền)."""
    amt = int(amount or 0)
    return (
        f"<b>{NOTICE_HEADER}</b> 🎉 Thông Báo\n"
        f"🎉 🧧 [BOT] Người chơi ID: {_mask_uid(uid)}\n"
        f"- Rút Bank thành công: <b>{_fmt_vn(amt)}</b>\n"
        f"{_hhmm(ts)}"
    )
