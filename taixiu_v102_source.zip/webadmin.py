"""
webadmin.py — WEB ADMIN PANEL cho hệ thống bot Tài Xỉu.
=============================================================================
Đọc/ghi CHUNG file dữ liệu `data.json` với bot Telegram (cùng định dạng
do storage.py tạo ra), nên số dư cập nhật ở web sẽ hiện ngay trong bot.

Chức năng:
  1. Đăng nhập admin (mật khẩu lấy từ .env: ADMIN_PASSWORD)
  2. Dashboard: tổng người chơi, tổng xu trong hệ thống
  3. Danh sách người chơi: ID Telegram, tên, số dư
  4. Cộng coin (add)     — cộng xu, ghi log
  5. Nạp coin (deposit)  — cộng xu, ghi log
  6. Rút coin (withdraw) — trừ xu (kiểm tra đủ số dư), ghi log
  7. Lịch sử giao dịch   — bảng nạp/rút/cộng

Chạy:  python webadmin.py     (mặc định cổng 5000)
"""
import json
import os
import random
import string
import threading
import time
import urllib.parse
import urllib.request
from functools import wraps

# --- Múi giờ Thái Lan (Asia/Bangkok, UTC+7) cho MỌI thời gian hiển thị/ghi ---
os.environ.setdefault("TZ", "Asia/Bangkok")
try:
    time.tzset()
except Exception:  # noqa: BLE001
    pass

from flask import (
    Flask, jsonify, redirect, render_template, request,
    session, url_for,
)
from dotenv import load_dotenv

import sys as _sys
_sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import notices  # noqa: E402  — mẫu THÔNG BÁO NẠP/RÚT dùng chung với bot

load_dotenv()

# ----------------------- Cấu hình -----------------------
# Resolve đường dẫn TUYỆT ĐỐI theo thư mục script, để web admin và bot luôn
# đọc/ghi CÙNG một file data.json dù chạy từ cwd nào.
BASE_DIR = os.path.dirname(os.path.abspath(__file__))


def _resolve(path: str, default: str) -> str:
    path = (path or "").strip() or default
    return path if os.path.isabs(path) else os.path.join(BASE_DIR, path)


DATA_FILE = _resolve(os.getenv("DATA_FILE", "data.json"), "data.json")
TX_FILE = _resolve(os.getenv("TX_FILE", "transactions.json"), "transactions.json")
ADMIN_PASSWORD = os.getenv("ADMIN_PASSWORD", "admin123").strip() or "admin123"
SECRET_KEY = os.getenv("WEB_SECRET_KEY", "taixiu-admin-secret-change-me").strip()
WEB_PORT = int(os.getenv("WEB_PORT", "5000").strip() or "5000")
# Token + chat id Telegram — dùng để gửi thông báo cho user khi admin duyệt/từ chối.
TELEGRAM_BOT_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN", "").strip()
TELEGRAM_CHAT_ID = os.getenv("TELEGRAM_CHAT_ID", "").strip()
WITHDRAW_FEE_PCT = 1.0
DEPOSIT_PROMO_PCT = 2.0       # khuyến mãi nạp (%)
WAGER_UNLOCK_PCT = 10.0       # cần cược 10% (nạp + KM) để được rút

app = Flask(__name__)
app.secret_key = SECRET_KEY

_lock = threading.RLock()


# ----------------------- I/O dữ liệu -----------------------
def _read_json(path, default):
    with _lock:
        if os.path.exists(path):
            try:
                with open(path, "r", encoding="utf-8") as f:
                    return json.load(f)
            except (json.JSONDecodeError, OSError):
                return default
        return default


def _write_json(path, data):
    """Ghi nguyên tử: file tạm -> os.replace (tránh hỏng dữ liệu)."""
    with _lock:
        tmp = f"{path}.tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
        os.replace(tmp, path)


def load_data():
    data = _read_json(DATA_FILE, {"users": {}})
    data.setdefault("users", {})
    data.setdefault("telegram_admins", [])
    return data


def save_data(data):
    _write_json(DATA_FILE, data)


def load_tx():
    tx = _read_json(TX_FILE, {"transactions": []})
    tx.setdefault("transactions", [])
    return tx


def add_tx(kind, user_id, username, amount, balance_after, note=""):
    """Ghi 1 giao dịch vào transactions.json."""
    tx = load_tx()
    tx["transactions"].append({
        "time": int(time.time()),
        "type": kind,            # add | deposit | withdraw
        "user_id": str(user_id),
        "username": username or "",
        "amount": int(amount),
        "balance_after": int(balance_after),
        "note": note,
    })
    # Giữ tối đa 2000 giao dịch gần nhất
    tx["transactions"] = tx["transactions"][-2000:]
    _write_json(TX_FILE, tx)


def _fmt_vn(n) -> str:
    """Định dạng số kiểu 1.000.000."""
    try:
        return f"{int(n):,}".replace(",", ".")
    except (TypeError, ValueError):
        return str(n)


def tg_notify(chat_id, text: str):
    """Gửi tin nhắn Telegram (HTML) bằng urllib — không cần thư viện ngoài.

    Trả về message_id (int) nếu thành công, None nếu thất bại.
    """
    if not TELEGRAM_BOT_TOKEN or not chat_id:
        return None
    try:
        url = f"https://api.telegram.org/bot{TELEGRAM_BOT_TOKEN}/sendMessage"
        payload = urllib.parse.urlencode({
            "chat_id": str(chat_id),
            "text": text,
            "parse_mode": "HTML",
            "disable_web_page_preview": "true",
        }).encode("utf-8")
        req = urllib.request.Request(url, data=payload)
        with urllib.request.urlopen(req, timeout=15) as resp:
            data = json.loads(resp.read().decode("utf-8"))
        if data.get("ok"):
            return data["result"].get("message_id")
    except Exception as e:  # noqa: BLE001
        print(f"⚠️ Không gửi được thông báo Telegram: {e}")
    return None


def collect_requests(data):
    """Gom TẤT CẢ yêu cầu NẠP + RÚT của mọi user (mới nhất trước)."""
    out = []
    for uid, u in data.get("users", {}).items():
        for kind, key in (("withdraw", "withdraw_requests"), ("deposit", "deposit_requests")):
            for i, r in enumerate(u.get(key) or []):
                out.append({
                    "kind": kind,
                    "user_id": uid,
                    "username": r.get("uname") or u.get("username") or uid,
                    "amount": int(r.get("amount", 0) or 0),
                    "fee": int(r.get("fee", 0) or 0),
                    "net": int(r.get("net", 0) or 0),
                    "bank_no": r.get("bank_no", "") or "",
                    "bank_name": r.get("bank_name", "") or "",
                    "bank_owner": r.get("bank_owner", "") or "",
                    "ts": int(r.get("ts", 0) or 0),
                    "status": r.get("status", "pending"),
                    "reason": r.get("reason", "") or "",
                    "order_no": str(r.get("order_no", "") or ""),
                    "approved_by": r.get("approved_by", "") or "",
                    "processed_ts": int(r.get("processed_ts", 0) or 0),
                    "index": i,
                })
    out.sort(key=lambda x: x["ts"], reverse=True)
    return out


def get_or_create_user(data, user_id, username=""):
    uid = str(user_id)
    users = data["users"]
    if uid not in users:
        users[uid] = {
            "balance": 0,
            "client_seed": f"player-{uid}",
            "server_seed": "",
            "server_seed_hash": "",
            "nonce": 0,
            "last_daily": 0,
            "history": [],
            "stats": {"bets": 0, "wins": 0, "losses": 0, "wagered": 0, "net": 0},
            "username": username or "",
        }
    if username:
        users[uid]["username"] = username
    users[uid].setdefault("balance", 0)
    return users[uid]


# ----------------------- Xác thực -----------------------
def login_required(f):
    @wraps(f)
    def wrapper(*args, **kwargs):
        if not session.get("logged_in"):
            if request.path.startswith("/api/"):
                return jsonify({"ok": False, "error": "Chưa đăng nhập"}), 401
            return redirect(url_for("login"))
        return f(*args, **kwargs)
    return wrapper


# ----------------------- Routes: trang -----------------------
@app.route("/login", methods=["GET", "POST"])
def login():
    error = None
    if request.method == "POST":
        pw = request.form.get("password", "")
        if pw == ADMIN_PASSWORD:
            session["logged_in"] = True
            return redirect(url_for("dashboard"))
        error = "Mật khẩu không đúng!"
    return render_template("login.html", error=error)


@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))


@app.route("/")
@login_required
def dashboard():
    return render_template("dashboard.html")


# ----------------------- API -----------------------
@app.route("/api/stats")
@login_required
def api_stats():
    data = load_data()
    users = data["users"]
    total_players = len(users)
    total_coins = sum(int(u.get("balance", 0)) for u in users.values())
    tx = load_tx()["transactions"]
    total_deposit = sum(t["amount"] for t in tx if t["type"] == "deposit")
    total_withdraw = sum(t["amount"] for t in tx if t["type"] == "withdraw")
    total_add = sum(t["amount"] for t in tx if t["type"] == "add")
    return jsonify({
        "ok": True,
        "total_players": total_players,
        "total_coins": total_coins,
        "total_deposit": total_deposit,
        "total_withdraw": total_withdraw,
        "total_add": total_add,
        "total_tx": len(tx),
    })


@app.route("/api/players")
@login_required
def api_players():
    data = load_data()
    players = []
    for uid, u in data["users"].items():
        players.append({
            "user_id": uid,
            "username": u.get("username", "") or "",
            "balance": int(u.get("balance", 0)),
        })
    players.sort(key=lambda p: p["balance"], reverse=True)
    return jsonify({"ok": True, "players": players})


@app.route("/api/transactions")
@login_required
def api_transactions():
    tx = load_tx()["transactions"]
    tx = list(reversed(tx))[:200]
    return jsonify({"ok": True, "transactions": tx})


# ----------------------- Quản lý NẠP / RÚT -----------------------
@app.route("/api/requests")
@login_required
def api_requests():
    """Danh sách yêu cầu NẠP + RÚT (pending + đã xử lý) — đọc real-time từ data.json."""
    data = load_data()
    reqs = collect_requests(data)
    pending = [r for r in reqs if r["status"] == "pending"]
    return jsonify({"ok": True, "requests": reqs, "pending": len(pending), "total": len(reqs)})


@app.route("/api/requests/action", methods=["POST"])
@login_required
def api_requests_action():
    """Duyệt / Từ chối 1 yêu cầu NẠP hoặc RÚT — ghi trực tiếp data.json + gửi Telegram cho user."""
    body = request.get_json(silent=True) or {}
    kind = (body.get("kind") or "").strip()
    user_id = str(body.get("user_id") or "").strip()
    decision = (body.get("decision") or "").strip()
    reason = (body.get("reason") or "").strip()
    try:
        index = int(body.get("index"))
    except (TypeError, ValueError):
        return jsonify({"ok": False, "error": "Thiếu chỉ số yêu cầu"}), 400
    if kind not in ("withdraw", "deposit"):
        return jsonify({"ok": False, "error": "Loại yêu cầu không hợp lệ"}), 400
    if decision not in ("approve", "reject"):
        return jsonify({"ok": False, "error": "Quyết định không hợp lệ"}), 400

    data = load_data()
    users = data["users"]
    if user_id not in users:
        return jsonify({"ok": False, "error": "Không tìm thấy người chơi"}), 404
    user = users[user_id]
    key = "withdraw_requests" if kind == "withdraw" else "deposit_requests"
    reqs = user.get(key) or []
    if index < 0 or index >= len(reqs):
        return jsonify({"ok": False, "error": "Yêu cầu không tồn tại"}), 404
    req = reqs[index]
    if req.get("status") != "pending":
        return jsonify({"ok": False, "error": f"Yêu cầu đã được xử lý ({req.get('status')})"}), 400

    amount = int(req.get("amount", 0) or 0)
    before = int(user.get("balance", 0))
    uname = req.get("uname") or user.get("username") or user_id
    chat_id = user_id  # Telegram user id
    label = "RÚT" if kind == "withdraw" else "NẠP"
    # v93: ghi NGƯỜI DUYỆT vào yêu cầu + transactions.json.
    approver = session.get("admin_user") or "admin"

    if decision == "approve":
        if kind == "withdraw":
            if amount <= 0:
                return jsonify({"ok": False, "error": "Yêu cầu rút này không có số tiền (yêu cầu cũ)."}), 400
            fee = int(req.get("fee", 0) or 0) or int(round(amount * WITHDRAW_FEE_PCT / 100.0))
            net = amount - fee
            if req.get("deducted"):
                # /rut đã trừ tiền lúc tạo yêu cầu → không trừ lại.
                after = before
            else:
                if amount > before:
                    return jsonify({"ok": False, "error": f"Không đủ số dư để duyệt rút! Hiện có {before:,} xu, cần {amount:,} xu."}), 400
                user["balance"] = before - amount
                after = int(user["balance"])
            req["status"] = "approved"
            req["fee"] = fee
            req["net"] = net
            req["processed_ts"] = int(time.time())
            req["approved_by"] = approver
            _order = str(req.get("order_no") or random.randint(100000000, 999999999))
            req["order_no"] = _order
            save_data(data)
            add_tx("withdraw", user_id, uname, amount, after, f"duyệt rút (phí {fee}) bởi {approver}")
            # MẪU MỚI (theo yêu cầu): mã đơn ĐỘNG + phí/thực nhận động.
            msg = (f"✅ Đơn rút <code>{_order}</code> đã được duyệt.\n"
                   f"- Rút Bank thành công: <b>{_fmt_vn(amount)}</b>\n"
                   "⚡ <i>Lệnh rút auto đã được gửi sang cổng Bank Out.</i>")
            # THÔNG BÁO RÚT TIỀN (đúng mẫu ảnh) — gửi lên NHÓM Telegram.
            tg_notify(TELEGRAM_CHAT_ID, notices.format_withdraw_notice(user_id, amount))
        else:  # deposit
            if amount <= 0:
                return jsonify({"ok": False, "error": "Yêu cầu nạp này không có số tiền."}), 400
            # KHUYẾN MÃI NẠP 2% (CẮT phần thập phân) — cộng vào số dư CÙNG tiền nạp.
            promo = int(amount * DEPOSIT_PROMO_PCT / 100.0)
            user["balance"] = before + amount + promo
            after = int(user["balance"])
            req["status"] = "approved"
            req["promo"] = promo
            req["processed_ts"] = int(time.time())
            req["approved_by"] = approver
            # Mã đối soát ĐỘNG: NAPTIEN + 6 ký tự chữ/số (mỗi giao dịch MỚI).
            deposit_code = "NAPTIEN " + "".join(
                random.choices(string.ascii_uppercase + string.digits, k=6))
            req["deposit_code"] = deposit_code
            save_data(data)
            add_tx("deposit", user_id, uname, amount, after, f"duyệt nạp (+KM {promo}) bởi {approver}")
            # MẪU MỚI (theo yêu cầu): Nạp tiền thành công + KM 2% + cần cược để rút
            # + số dư hiện tại + mã đối soát. "Cần cược để rút" = 10% SỐ TIỀN NẠP, làm tròn 10đ
            # (VD 30.432 -> 3.043,2 -> 3.040 — khớp mẫu user).
            _need = int(round(amount * WAGER_UNLOCK_PCT / 100.0, -1))
            msg = notices.build_deposit_approved_msg(amount, promo, _need, after, deposit_code)
            # THÔNG BÁO NẠP TIỀN (đúng mẫu ảnh) — gửi lên NHÓM Telegram.
            tg_notify(TELEGRAM_CHAT_ID, notices.format_deposit_notice(user_id, amount, promo=promo))
    else:  # reject
        req["status"] = "rejected"
        req["processed_ts"] = int(time.time())
        req["approved_by"] = approver
        if reason:
            req["reason"] = reason
        save_data(data)
        after = before
        reason_line = f"\n│ 📝 Lý do: <b>{reason}</b>" if reason else ""
        msg = (f"❌ <b>YÊU CẦU {label} TIỀN BỊ TỪ CHỐI</b>\n"
               "┌──────────────────────\n"
               f"│ 💸 Số tiền: <b>{_fmt_vn(amount)} xu</b>\n"
               f"│ 💳 Số dư hiện tại: <b>{_fmt_vn(after)} xu</b>{reason_line}\n"
               "└──────────────────────\n"
               "Vui lòng liên hệ admin nếu cần hỗ trợ thêm.")

    mid = tg_notify(chat_id, msg)
    return jsonify({
        "ok": True,
        "message": f"Đã {'duyệt' if decision == 'approve' else 'từ chối'} yêu cầu {label}.",
        "status": req["status"],
        "before": before,
        "after": after,
        "msg_id": mid,
    })


# ----------------------- Quản lý admin TELEGRAM -----------------------
@app.route("/api/telegram_admins")
@login_required
def api_telegram_admins():
    """Danh sách admin Telegram (user_id hoặc username) — bot đọc real-time từ data.json."""
    data = load_data()
    return jsonify({"ok": True, "admins": data.get("telegram_admins", [])})


@app.route("/api/telegram_admins/add", methods=["POST"])
@login_required
def api_telegram_admins_add():
    body = request.get_json(silent=True) or {}
    value = str(body.get("value") or "").strip().lstrip("@")
    if not value:
        return jsonify({"ok": False, "error": "Thiếu username hoặc user_id Telegram"}), 400
    data = load_data()
    admins = data.setdefault("telegram_admins", [])
    if value.lower() in [str(a).lower() for a in admins]:
        return jsonify({"ok": False, "error": f"'{value}' đã là admin Telegram rồi"}), 400
    admins.append(value)
    save_data(data)
    return jsonify({"ok": True, "message": f"Đã thêm admin Telegram: {value}", "admins": admins})


@app.route("/api/telegram_admins/remove", methods=["POST"])
@login_required
def api_telegram_admins_remove():
    body = request.get_json(silent=True) or {}
    value = str(body.get("value") or "").strip().lstrip("@")
    if not value:
        return jsonify({"ok": False, "error": "Thiếu username hoặc user_id Telegram"}), 400
    data = load_data()
    admins = data.setdefault("telegram_admins", [])
    new_admins = [a for a in admins if str(a).lower() != value.lower()]
    if len(new_admins) == len(admins):
        return jsonify({"ok": False, "error": f"Không tìm thấy admin Telegram '{value}'"}), 400
    data["telegram_admins"] = new_admins
    save_data(data)
    return jsonify({"ok": True, "message": f"Đã xoá admin Telegram: {value}", "admins": new_admins})


@app.route("/api/action", methods=["POST"])
@login_required
def api_action():
    """Xử lý add / deposit / withdraw."""
    body = request.get_json(silent=True) or {}
    kind = (body.get("type") or "").strip()
    user_id = str(body.get("user_id") or "").strip()
    username = (body.get("username") or "").strip()
    note = (body.get("note") or "").strip()

    if kind not in ("add", "deposit", "withdraw"):
        return jsonify({"ok": False, "error": "Loại giao dịch không hợp lệ"}), 400
    if not user_id:
        return jsonify({"ok": False, "error": "Thiếu ID người chơi"}), 400
    try:
        amount = int(body.get("amount"))
    except (TypeError, ValueError):
        return jsonify({"ok": False, "error": "Số xu không hợp lệ"}), 400
    if amount <= 0:
        return jsonify({"ok": False, "error": "Số xu phải là số nguyên dương"}), 400

    data = load_data()
    user = get_or_create_user(data, user_id, username)
    before = int(user.get("balance", 0))

    if kind == "withdraw":
        if amount > before:
            return jsonify({
                "ok": False,
                "error": f"Không đủ số dư! Hiện có {before:,} xu, cần rút {amount:,} xu.",
            }), 400
        user["balance"] = before - amount
    else:  # add | deposit
        user["balance"] = before + amount

    after = int(user["balance"])
    save_data(data)
    add_tx(kind, user_id, username, amount, after, note)

    label = {"add": "Cộng coin", "deposit": "Nạp coin", "withdraw": "Rút coin"}[kind]
    return jsonify({
        "ok": True,
        "message": f"{label} thành công!",
        "user_id": user_id,
        "username": username,
        "before": before,
        "after": after,
        "amount": amount,
    })


if __name__ == "__main__":
    print("=" * 60)
    print("  WEB ADMIN PANEL — Bot Tài Xỉu")
    print(f"  Dữ liệu: {DATA_FILE}  |  Giao dịch: {TX_FILE}")
    print(f"  Mở trình duyệt (CHỈ localhost): http://127.0.0.1:{WEB_PORT}")
    print(f"  Mật khẩu admin: {'(từ .env)' if os.getenv('ADMIN_PASSWORD') else 'admin123 (mặc định)'}")
    print("  ⚠️  Web admin CHỈ bind 127.0.0.1 — KHÔNG lộ ra ngoài. Truy cập qua SSH tunnel.")
    print("=" * 60)
    # v53: CHỈ bind localhost — không lộ web admin ra Internet.
    app.run(host="127.0.0.1", port=WEB_PORT, debug=False)
