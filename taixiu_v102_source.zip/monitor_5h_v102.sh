#!/usr/bin/env bash
# monitor_5h_v102.sh — Giam sat bot Tai Xiu _v102 LIEN TUC 5 gio, kiem tra moi 30 phut.
# Moi lan: dem tien trinh (bot.py / webadmin.py / start_tunnel_lhr.sh / run_forever.sh),
#          uptime tien trinh bot, so traceback trong bot_run_v102.log, /login HTTP status.
#          Neu thieu tien trinh -> chay watchdog.sh de ho sinh.
# Ghi: monitor_5h_v102.log (text) + evidence/uptime_5h_v102_status.json (JSON moi lan check).
# Chay detached: setsid nohup ./monitor_5h_v102.sh >/dev/null 2>&1 </dev/null &
set -u
cd "$(dirname "$0")" || exit 1
export TZ=Asia/Bangkok
export PATH="/usr/local/bin:$PATH"
LOG="monitor_5h_v102.log"
STATUS="evidence/uptime_5h_v102_status.json"
STARTJSON="evidence/uptime_5h_v102_start.json"
DURATION=18000   # 5 gio (giay)
INTERVAL=1800    # 30 phut (giay)
START=$(date +%s)
STARTISO=$(date -Iseconds)
ts() { date '+%Y-%m-%d %H:%M:%S'; }
mkdir -p evidence
restarts=0
checks=0

# uptime tien trinh bot (giay) tu /proc/<pid>/stat (field 22 starttime, hertz=100)
bot_uptime() {
  local pid st hz boot now
  pid=$(pgrep -f "bot.py" | head -1)
  [ -z "$pid" ] && { echo 0; return; }
  st=$(awk '{print $22}' /proc/$pid/stat 2>/dev/null)
  [ -z "$st" ] && { echo 0; return; }
  hz=$(getconf CLK_TCK 2>/dev/null || echo 100)
  boot=$(awk '/btime/{print $2}' /proc/stat 2>/dev/null)
  now=$(date +%s)
  echo $(( now - boot - st / hz ))
}

write_start() {
  cat > "$STARTJSON" <<EOF
{
  "version": "_v102",
  "monitor": "monitor_5h_v102.sh",
  "started_at": "$STARTISO",
  "duration_seconds": $DURATION,
  "interval_seconds": $INTERVAL,
  "timezone": "Asia/Bangkok",
  "cwd": "$(pwd)",
  "bot_pgrep": $(pgrep -fc "bot.py"),
  "webadmin_pgrep": $(pgrep -fc "webadmin.py"),
  "tunnel_pgrep": $(pgrep -fc "start_tunnel_lhr.sh"),
  "run_forever_pgrep": $(pgrep -fc "run_forever.sh"),
  "monitor_pid": $$
}
EOF
}

write_status() {
  local bot w t rf tb login up now iso
  bot=$(pgrep -fc "bot.py")
  w=$(pgrep -fc "webadmin.py")
  t=$(pgrep -fc "start_tunnel_lhr.sh")
  rf=$(pgrep -fc "run_forever.sh")
  tb=$(grep -c Traceback "bot_run_v102.log" 2>/dev/null); tb=${tb:-0}
  login=$(curl -s -o /dev/null -w "%{http_code}" http://127.0.0.1:5000/login 2>/dev/null)
  up=$(bot_uptime)
  now=$(date +%s); iso=$(date -Iseconds)
  cat > "$STATUS" <<EOF
{
  "version": "_v102",
  "updated_at": "$iso",
  "elapsed_seconds": $(( now - START )),
  "checks": $checks,
  "restarts": $restarts,
  "processes": {"bot": $bot, "webadmin": $w, "tunnel": $t, "run_forever": $rf, "monitor": 1},
  "bot_uptime_seconds": $up,
  "traceback_count": $tb,
  "login_http": "$login",
  "all_ok": $([ "$bot" -ge 1 ] && [ "$w" -ge 1 ] && [ "$t" -ge 1 ] && [ "$rf" -ge 1 ] && [ "$login" = "200" ] && [ "$tb" -eq 0 ] && echo true || echo false)
}
EOF
}

check() {
  local b w t rf tb login up
  b=$(pgrep -fc "bot.py"); w=$(pgrep -fc "webadmin.py")
  t=$(pgrep -fc "start_tunnel_lhr.sh"); rf=$(pgrep -fc "run_forever.sh")
  tb=$(grep -c Traceback "bot_run_v102.log" 2>/dev/null); tb=${tb:-0}
  login=$(curl -s -o /dev/null -w "%{http_code}" http://127.0.0.1:5000/login 2>/dev/null)
  up=$(bot_uptime)
  checks=$((checks+1))
  echo "[$(ts)] check#$checks bot=$b webadmin=$w tunnel=$t run_forever=$rf traceback=$tb login=$login bot_uptime=${up}s" >> "$LOG"
  if [ "$b" -lt 1 ] || [ "$w" -lt 1 ] || [ "$t" -lt 1 ] || [ "$rf" -lt 1 ]; then
    echo "[$(ts)] !! THIEU TIEN TRINH -> chay watchdog.sh" >> "$LOG"
    ./watchdog.sh >> "$LOG" 2>&1
    restarts=$((restarts+1))
    sleep 5
    echo "[$(ts)] sau watchdog: bot=$(pgrep -fc bot.py) webadmin=$(pgrep -fc webadmin.py) tunnel=$(pgrep -fc start_tunnel_lhr.sh) run_forever=$(pgrep -fc run_forever.sh)" >> "$LOG"
  fi
  write_status
}

write_start
echo "=== MONITOR 5H v101 BAT DAU $(ts) (PID $$) | duration=${DURATION}s interval=${INTERVAL}s ===" >> "$LOG"

while true; do
  now=$(date +%s)
  elapsed=$((now - START))
  if [ "$elapsed" -ge "$DURATION" ]; then break; fi
  check
  sleep "$INTERVAL"
done
check
echo "=== MONITOR 5H v101 KET THUC $(ts) | elapsed=$(( $(date +%s) - START ))s checks=$checks restarts=$restarts ===" >> "$LOG"
