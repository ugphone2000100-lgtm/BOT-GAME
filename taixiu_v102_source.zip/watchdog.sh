#!/usr/bin/env bash
# watchdog.sh (v100) — Tự động kiểm tra và bật lại bot + web admin + tunnel public nếu chết.
# Dùng: chạy định kỳ qua cron (*/2 * * * *) hoặc @reboot, hoặc gọi từ .bashrc (self-heal).
set -u
cd "$(dirname "$0")" || exit 1
export TZ=Asia/Bangkok
export PATH="/usr/local/bin:$PATH"   # v87: cron PATH thieu /usr/local/bin -> thieu module dotenv
LOG="watchdog_v102.log"
ts() { date '+%Y-%m-%d %H:%M:%S'; }

# 0) Đảm bảo cron daemon sống (nếu không thì @reboot/*/2 sẽ không bao giờ chạy)
if ! pgrep -x cron >/dev/null 2>&1; then
    service cron start >/dev/null 2>&1 || true
fi

# 1) Supervisor keep-alive (run_forever.sh) — bảo đảm bot luôn được giám sát
if ! pgrep -f "run_forever.sh" >/dev/null 2>&1; then
    echo "[$(ts)] run_forever.sh KHONG chay -> khoi dong lai" >> "$LOG"
    setsid nohup ./run_forever.sh > /dev/null 2>&1 < /dev/null &
fi

# 2) Nếu supervisor còn nhưng bot.py không chạy -> kill+restart supervisor
if ! pgrep -f "bot.py" >/dev/null 2>&1; then
    sleep 3
    if ! pgrep -f "bot.py" >/dev/null 2>&1; then
        echo "[$(ts)] bot.py KHONG chay -> restart supervisor" >> "$LOG"
        pkill -f "run_forever.sh" 2>/dev/null
        rm -f run_forever_v102.lock 2>/dev/null
        sleep 1
        setsid nohup ./run_forever.sh > /dev/null 2>&1 < /dev/null &
    fi
fi

# 3) Web admin Flask
if ! pgrep -f "webadmin.py" >/dev/null 2>&1; then
    echo "[$(ts)] webadmin.py KHONG chay -> khoi dong lai" >> "$LOG"
    setsid nohup python3 -u webadmin.py > "web_run_v102.log" 2>&1 < /dev/null &
fi

# 4) Tunnel public (cloudflared) — v68: giữ link public sống 24/7
if ! pgrep -f "start_tunnel_lhr.sh" >/dev/null 2>&1; then
    echo "[$(ts)] tunnel KHONG chay -> khoi dong lai (LHR)" >> "$LOG"
    rm -f tunnel_lhr_v102.lock 2>/dev/null
    setsid nohup ./start_tunnel_lhr.sh > /dev/null 2>&1 < /dev/null &
fi

# 5) Monitor 5h (v100) — giữ giám sát uptime sống suốt 5 giờ
if [ -f monitor_5h_v102.sh ] && ! pgrep -f "monitor_5h_v102.sh" >/dev/null 2>&1; then
    echo "[$(ts)] monitor_5h_v102.sh KHONG chay -> khoi dong lai" >> "$LOG"
    setsid nohup ./monitor_5h_v102.sh > /dev/null 2>&1 < /dev/null &
fi

exit 0
