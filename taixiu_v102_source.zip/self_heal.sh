#!/usr/bin/env bash
# self_heal.sh (v80) — Hook tự phục hồi: gọi từ .bashrc mỗi khi có shell mới.
# Throttle 60s để không spam. Đảm bảo bot + web admin + tunnel public luôn sống sau mỗi lần sandbox restart.
DIR="/workspace/documents/discord-taixiu-bot_v102"
STAMP="/tmp/.taixiu_selfheal_stamp"
NOW=$(date +%s)
LAST=$(cat "$STAMP" 2>/dev/null || echo 0)
if [ $((NOW - LAST)) -lt 60 ]; then
    exit 0
fi
echo "$NOW" > "$STAMP"
cd "$DIR" 2>/dev/null || exit 0
export TZ=Asia/Bangkok
export PATH="/usr/local/bin:$PATH"   # v87: cron PATH thieu /usr/local/bin -> thieu module dotenv
# chỉ chạy nếu bot / webadmin / tunnel chưa sống
if ! pgrep -f "run_forever.sh" >/dev/null 2>&1 \
   || ! pgrep -f "webadmin.py" >/dev/null 2>&1 \
   || ! pgrep -f "start_tunnel_lhr.sh" >/dev/null 2>&1; then
    setsid nohup ./watchdog.sh >/dev/null 2>&1 </dev/null &
fi
exit 0
