"""
telegram_commands.py — Lệnh Telegram tương tác cho bot Tài Xỉu.
================================================================

Hiện hỗ trợ:
    /webadmin   → trả về LINK web admin public hiện tại + mật khẩu admin (CHỈ admin, ẩn khỏi menu).
    /rut <tiền> → rút tiền về STK đã liên kết (VD /rut 50000, /rut all).
    /stk        → xem / đổi số tài khoản đã liên kết.

Đặc điểm:
  - URL được đọc ĐỘNG từ file `webadmin_url.txt` (do tiến trình cloudflared ghi ra),
    nên mỗi khi tunnel đổi URL thì lệnh vẫn trả link ĐÚNG, KHÔNG hardcode URL cũ.
  - Chỉ ADMIN (theo ADMIN_USERNAME trong .env, mặc định "thandam789") dùng được.
    Người khác gõ /webadmin sẽ bị từ chối để không lộ link.
  - Dùng long-polling getUpdates của Telegram Bot API (aiohttp), chạy song song
    trong event loop của bot — không cần thư viện ngoài.

Cấu hình qua .env:
    TELEGRAM_BOT_TOKEN=...        # token bot Telegram (đã có)
    ADMIN_USERNAME=thandam789     # username admin được phép dùng /webadmin
    ADMIN_PASSWORD=admin123       # mật khẩu web admin hiển thị kèm link
    WEBADMIN_URL_FILE=webadmin_url.txt   # (tùy chọn) file chứa URL tunnel hiện tại
"""
import asyncio
import json
import os
import time
import urllib.parse

import bet_parser
from telegram_dice import _premiumize

try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:  # pragma: no cover
    pass

try:
    import aiohttp
except ImportError:  # pragma: no cover
    aiohttp = None

TELEGRAM_API = "https://api.telegram.org/bot{token}/{method}"

# File chứa URL web admin hiện tại (do cloudflared/tiến trình tunnel ghi ra).
URL_FILE = os.getenv("WEBADMIN_URL_FILE", "webadmin_url.txt").strip() or "webadmin_url.txt"
# Mật khẩu web admin hiển thị kèm link.
ADMIN_PASSWORD = os.getenv("ADMIN_PASSWORD", "admin123").strip() or "admin123"
# Username admin được phép dùng lệnh (không có '@').
ADMIN_USERNAME = os.getenv("ADMIN_USERNAME", "thandam789").strip().lstrip("@").lower()
# Danh sách username admin (nhiều tên, phân tách bởi dấu phẩy) — hỗ trợ cả 'thandam789' và 'Thandam78'.
ADMIN_USERNAMES = {
    u.strip().lstrip("@").lower()
    for u in os.getenv("ADMIN_USERNAMES", "thandam789,thandam78").split(",")
    if u.strip()
}
# ID Telegram của admin (số) — ưu tiên khớp theo ID để chắc chắn đúng người.
ADMIN_TELEGRAM_ID = os.getenv("ADMIN_TELEGRAM_ID", "").strip()

# ----------------------- Cấu hình RÚT TIỀN -----------------------
WITHDRAW_FEE_PCT = 1.0        # phí rút (%)
WITHDRAW_MIN = 50_000         # rút tối thiểu mỗi lần
WITHDRAW_MAX = 10_000_000     # rút tối đa mỗi lần
NEWBIE_RESERVED = 1_000       # số dư tân thủ giữ lại
WAGER_MULT = 3                # mốc cược = tiền nạp + số dư tân thủ x3

# ----------------------- Cấu hình NẠP TIỀN -----------------------
DEPOSIT_MIN = 10_000              # nạp tối thiểu
DEPOSIT_MAX = 500_000_000         # nạp tối đa
DEPOSIT_TTL = 600                 # hiệu lực 10 phút
DEPOSIT_BANK_NAME = "VIB"         # v99: ngan hang VIB (vibbank)
DEPOSIT_BANK_NO = "810065"        # v99: STK nap = 810065
DEPOSIT_BANK_OWNER = "TTNS"       # v99: chu TK = TTNS
DEPOSIT_BANK_BIN = "970441"       # BIN VIB (VietQR)
# 10 mệnh giá nạp (2 hàng × 5 nút).
DEPOSIT_DENOMS = [20_000, 50_000, 100_000, 200_000, 500_000,
                  1_000_000, 2_000_000, 3_000_000, 5_000_000, 10_000_000]


def _fmt_denom(n: int) -> str:
    """Nhãn mệnh giá gọn: 20000 -> 20K, 1000000 -> 1M."""
    if n >= 1_000_000:
        return f"{n / 1_000_000:g}M"
    if n >= 1_000:
        return f"{n / 1_000:g}K"
    return str(n)


def _fmt_vn(n) -> str:
    """Định dạng số kiểu 1.000.000."""
    try:
        return f"{int(n):,}".replace(",", ".")
    except (TypeError, ValueError):
        return str(n)

# File dữ liệu chung với bot/web admin — chứa danh sách admin Telegram ĐỘNG.
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_FILE = os.getenv("DATA_FILE", "data.json").strip() or "data.json"
if not os.path.isabs(DATA_FILE):
    DATA_FILE = os.path.join(BASE_DIR, DATA_FILE)


def read_telegram_admins():
    """Đọc danh sách admin Telegram ĐỘNG từ data.json (bot đọc real-time, không cần restart).

    Mỗi phần tử là 1 chuỗi: user_id (số) hoặc username (không có '@').
    """
    try:
        with open(DATA_FILE, "r", encoding="utf-8") as f:
            data = json.load(f)
        admins = data.get("telegram_admins") or []
        return [str(a).strip().lstrip("@").lower() for a in admins if str(a).strip()]
    except (OSError, json.JSONDecodeError):
        return []


# Hook đặt cược: bot.py đăng ký hàm (uid, username, text) -> str (thông báo kết quả).
# Cho phép tin nhắn cược chữ liền trên Telegram dùng parser chung.
_BET_HANDLER = None


def set_bet_handler(fn):
    """Đăng ký hàm xử lý đặt cược từ Telegram (do bot.py gọi lúc khởi động)."""
    global _BET_HANDLER
    _BET_HANDLER = fn


# Hook cộng xu (lệnh admin /addcoin trên Telegram): bot.py đăng ký hàm (user_id, amount) -> str.
_ADDCOIN_HANDLER = None


def set_addcoin_handler(fn):
    """Đăng ký hàm cộng xu cho lệnh admin /addcoin trên Telegram."""
    global _ADDCOIN_HANDLER
    _ADDCOIN_HANDLER = fn


def read_webadmin_url() -> str:
    """Đọc URL web admin hiện tại từ file (đọc ĐỘNG mỗi lần gọi)."""
    try:
        with open(URL_FILE, "r", encoding="utf-8") as f:
            url = f.read().strip()
        return url
    except OSError:
        return ""


def _is_admin(from_user: dict) -> bool:
    """Kiểm tra người gửi có phải admin không (theo ID Telegram hoặc username)."""
    if not from_user:
        return False
    uid = str(from_user.get("id") or "")
    if ADMIN_TELEGRAM_ID and uid == ADMIN_TELEGRAM_ID:
        return True
    uname = (from_user.get("username") or "").lstrip("@").lower()
    if uname and (uname == ADMIN_USERNAME or uname in ADMIN_USERNAMES):
        return True
    # Danh sách admin ĐỘNG (thêm/xoá trên web admin) — đọc real-time từ data.json.
    dynamic = read_telegram_admins()
    if uid and uid.lower() in dynamic:
        return True
    if uname and uname in dynamic:
        return True
    return False


# ── Nội dung tin nhắn chào mừng (/start, /help) ────────────────────────────────
# Dòng đầu hiển thị ID Telegram THẬT của người gửi; dòng cuối là link Room TX.
# (v40: chỉ còn 2 dòng — đã xoá 2 dòng hướng dẫn ở giữa.)
WELCOME_TEMPLATE = (
    "🆔 ID của bạn là {uid}\n"
    "\n"
    "🏛 Tham gia Room TX để săn hũ và nhận giftcode hằng ngày https://t.me/et99sangame"
)


def _welcome_text(uid: str) -> str:
    """Nội dung chào mừng cho /start, /help — dòng đầu là ID Telegram thật."""
    return WELCOME_TEMPLATE.format(uid=uid)


# ── Inline keyboard 8 nút dưới tin nhắn /start (2 cột × 4 hàng) ──────────────
# Bố cục + nhãn theo ảnh người dùng gửi.
# ── Bàn phím nút CHÍNH (ReplyKeyboard) — KHÔI PHỤC ĐỦ 8 NÚT BẤM NHANH (v76).
# v76: user phàn nàn v75 xoá ReplyKeyboard nên không còn nút bấm nhanh dưới ô nhập.
# Nay ReplyKeyboard có LẠI đủ 8 nút: Danh sách game · Tài Khoản · Nạp Tiền · Rút Tiền ·
# Giới Thiệu · Đua top · Event · Lệnh (hàng đầu 1 nút, các hàng sau 2 nút).
# ĐỒNG THỜI vẫn giữ MENU CHÍNH dạng INLINE + PREMIUM EMOJI gửi kèm /start (tin nhắn riêng).
# 7 nút menu vẫn dùng được qua LỆNH: /tk · /nap · /rut · /gt · /top · /event · /lenh
# HOẶC gõ thẳng TÊN mục (không dấu "/"): "Tài Khoản" · "Nạp Tiền" · "Rút Tiền" ·
# "Giới Thiệu" · "Đua top" · "Event" · "Lệnh" — bot trả TIN NHẮN y hệt bấm nút cũ.
# v74: KHÔI PHỤC ĐẦY ĐỦ nút bấm nhanh trong ReplyKeyboard (user chê 1 nút quá ít).
# Bấm nút -> Telegram gửi text = nhãn nút -> resolve_button_label() xử lý y hệt gõ lệnh.
# Mỗi emoji trên nút là PREMIUM (`icon_custom_emoji_id`), nhãn là text thường.
# Hàng 1: "Danh sách game" (1 nút). Các hàng sau: 2 nút/hàng.
# v88: KHÔI PHỤC ReplyKeyboard "tin nhắn nhanh" như CŨ (v76) — 8 nút menu CHÍNH hiển thị
#   THƯỜNG TRỰC dưới ô nhập tin nhắn: Danh sách game + Tài Khoản/Nạp/Rút/Giới Thiệu/Đua top/Event/Lệnh.
#   (13 nút phụ LS nạp/LS rút/... KHÔNG nằm ở đây — chúng CHỈ là INLINE gắn vào tin nhắn TÀI KHOẢN.)
# Bấm nút -> Telegram gửi text = nhãn nút -> resolve_button_label() xử lý.
REPLY_KEYBOARD_ROWS = [
    [("Danh sách game", "menu:games")],
    [("Tài Khoản", "menu:account"), ("Nạp Tiền", "menu:deposit")],
    [("Rút Tiền", "menu:withdraw"), ("Giới Thiệu", "menu:intro")],
    [("Đua top cược", "menu:top"), ("Event", "menu:event")],
    [("Lệnh", "menu:commands")],
]
# Giữ tên cũ để tương thích (một số chỗ import START_KEYBOARD_ROWS).
START_KEYBOARD_ROWS = REPLY_KEYBOARD_ROWS

# v74: ReplyKeyboard CỦA TELEGRAM KHÔNG render custom (premium) emoji trong nhãn nút
#   → hiển thị emoji UNICODE thường đứng trước nhãn (vẫn bấm được, gửi đúng tin nhắn).
#   (Premium emoji chỉ dùng được trên INLINE keyboard qua `icon_custom_emoji_id`.)
REPLY_BUTTON_EMOJI = {
    "LS nạp": "📈", "LS rút": "⌛", "LS chơi": "🕹️", "LS Room TX": "📄",
    "Nhập giftcode": "🎁", "Mua giftcode": "🟣", "Nhận thưởng": "🎁", "Chuyển tiền": "₿",
    "VIP": "👑", "Fan cứng +30k": "🔥", "Tích lũy nạp": "💎", "Két Sắt": "🏦",
    "Hỗ trợ": "🦊",
    # Nhãn menu cũ (vẫn dùng cho inline menu / gõ tay).
    "Danh sách game": "🎮", "Tài Khoản": "👤", "Nạp Tiền": "💰", "Rút Tiền": "💸",
    "Giới Thiệu": "🎁", "Đua top cược": "🏆", "Event": "🎉", "Lệnh": "🔍",
}
ROOM_TX_URL = "https://t.me/et99sangame"

# Icon custom emoji (PREMIUM) cho từng nút — Bot API 9.4 `icon_custom_emoji_id`.
# Telegram hiển thị emoji premium ngay trước nhãn chữ của nút (cả ReplyKeyboard lẫn InlineKeyboard).
BUTTON_ICON_IDS = {
    "Danh sách game": "5361741454685256344",   # 🎮
    "Tài Khoản": "5373012449597335010",        # 👤
    "Nạp Tiền": "5375296873982604963",         # 💰
    "Rút Tiền": "5233326571099534068",         # 💸
    "Giới Thiệu": "5199749070830197566",       # 🎁
    "Đua top cược": "5409008750893734809",      # 🏆
    "Event": "5461151367559141950",            # 🎉
    "Lệnh": "5231012545799666522",             # 🔍
}

# v75: bảng EMOJI -> custom_emoji_id cho MỌI nút inline (premium emoji).
# Emoji KHÔNG có bản premium (🎲 🎰 🎴 🔴 🔵 ⚪️ ⚫️ 📜 💳 🆔 🎟️) KHÔNG có trong bảng này
# -> nút giữ Unicode theo quy ước, TUYỆT ĐỐI không gán ID sai nghĩa.
EMOJI_ICON_IDS = {
    "🎮": "5361741454685256344", "👤": "5373012449597335010",
    "💰": "5375296873982604963", "🏦": "5264895611517300926",
    "🎁": "5199749070830197566", "🏆": "5409008750893734809",
    "🎉": "5461151367559141950", "🔍": "5231012545799666522",
    "💸": "5233326571099534068", "✅": "5427009714745517609",
    "✏️": "5395444784611480792", "🔗": "5271604874419647061",
    "📈": "5244837092042750681", "⌛": "5386367538735104399",
    "👑": "5217822164362739968", "🔥": "5424972470023104089",
    "💎": "5427168083074628963", "🦊": "5283051451889756068",
    "🦀": "5222474515887435551", "🆚": "5470076726212042350",
    "⚽️": "5373101763442255191", "🏀": "5384088040677319401",
    "✊": "5472404692975753822", "💥": "5276032951342088188",
}


def _btn(text: str, cb: str, emoji: str = "") -> dict:
    """Nút inline: gắn `icon_custom_emoji_id` (PREMIUM) nếu emoji có bản premium.

    Emoji không có bản premium -> giữ Unicode trong nhãn (quy ước bắt buộc).
    """
    btn = {"text": text, "callback_data": cb}
    icon = EMOJI_ICON_IDS.get(emoji) if emoji else None
    if icon:
        btn["icon_custom_emoji_id"] = icon
    return btn


# ── InlineKeyboard MENU CHÍNH (7 nút) — 7 nút đã bỏ khỏi ReplyKeyboard, nay là nút BẤM inline.
MENU_ROWS = [
    [("Tài Khoản", "menu:account"), ("Nạp Tiền", "menu:deposit")],
    [("Rút Tiền", "menu:withdraw"), ("Giới Thiệu", "menu:intro")],
    [("Đua top cược", "menu:top"), ("Event", "menu:event")],
    [("Lệnh", "menu:commands")],
]

# v75: MENU CHÍNH gửi kèm /start — THÊM nút "Danh sách game" (8 nút, TẤT CẢ inline + premium).
START_MENU_ROWS = [
    [("Danh sách game", "menu:games")],
    [("Tài Khoản", "menu:account"), ("Nạp Tiền", "menu:deposit")],
    [("Rút Tiền", "menu:withdraw"), ("Giới Thiệu", "menu:intro")],
    [("Đua top cược", "menu:top"), ("Event", "menu:event")],
    [("Lệnh", "menu:commands")],
]

# Map nhãn nút -> callback_data (dùng cho ReplyKeyboard: bấm nút gửi text = nhãn).
BUTTON_LABEL_TO_DATA = {label: data for row in REPLY_KEYBOARD_ROWS for label, data in row}
# Cho phép gõ tay nhãn nút menu -> vẫn mở đúng mục (dù không còn trên bàn phím nút).
BUTTON_LABEL_TO_DATA.update({label: data for row in MENU_ROWS for label, data in row})

# v73: gõ tay TÊN mục (KHÔNG dấu "/") -> bot trả TIN NHẮN đúng như bấm nút cũ.
# Vd gõ "Tài Khoản" / "Nạp Tiền" / "Rút Tiền" ... (kể cả không dấu) đều chạy.
MENU_TEXT_ALIASES = {
    "tài khoản": "menu:account", "tai khoan": "menu:account", "tk": "menu:account",
    "nạp tiền": "menu:deposit", "nap tien": "menu:deposit", "nạp": "menu:deposit", "nap": "menu:deposit",
    "rút tiền": "menu:withdraw", "rut tien": "menu:withdraw", "rút": "menu:withdraw", "rut": "menu:withdraw",
    "giới thiệu": "menu:intro", "gioi thieu": "menu:intro", "gt": "menu:intro",
    "đua top": "menu:top", "dua top": "menu:top", "đua top ": "menu:top", "top": "menu:top",
    "đua top cược": "menu:top", "dua top cuoc": "menu:top", "đua top cuoc": "menu:top", "dua top cược": "menu:top",
    "sự kiện": "menu:event", "su kien": "menu:event", "event": "menu:event",
    "lệnh": "menu:commands", "lenh": "menu:commands",
    "danh sách game": "menu:games", "danh sach game": "menu:games",
    # v84: alias cho 13 nút ReplyKeyboard mới (gõ tay vẫn mở đúng mục).
    "ls nạp": "menu:lsnap", "ls nap": "menu:lsnap",
    "ls rút": "menu:lsrut", "ls rut": "menu:lsrut",
    "ls chơi": "menu:lschoi", "ls choi": "menu:lschoi",
    "ls room tx": "menu:lsroom", "ls room": "menu:lsroom",
    "nhập giftcode": "menu:giftcode", "nhap giftcode": "menu:giftcode", "giftcode": "menu:giftcode",
    "mua giftcode": "menu:muagiftcode",
    "nhận thưởng": "menu:nhanthuong", "nhan thuong": "menu:nhanthuong",
    "chuyển tiền": "menu:chuyentien", "chuyen tien": "menu:chuyentien",
    "vip": "menu:vip",
    "fan cứng +30k": "menu:fancung", "fan cung +30k": "menu:fancung", "fan cứng": "menu:fancung", "fan cung": "menu:fancung",
    "tích lũy nạp": "menu:tichluy", "tich luy nap": "menu:tichluy", "tích lũy": "menu:tichluy", "tich luy": "menu:tichluy",
    "két sắt": "menu:ketsat", "ket sat": "menu:ketsat",
    "hỗ trợ": "menu:hotro", "ho tro": "menu:hotro",
}


# v77: các mục CHỈ dùng ở CHAT RIÊNG — trong NHÓM bị ẩn nút + chặn ở tầng handler.
GROUP_HIDDEN = {"menu:account", "menu:deposit", "menu:withdraw"}
# Username bot (để mở link chat riêng khi từ chối trong nhóm).
BOT_USERNAME = os.getenv("TELEGRAM_BOT_USERNAME", "et99_sangame_bot").strip().lstrip("@")


def _is_group_chat(chat: dict) -> bool:
    """True nếu chat là NHÓM / siêu nhóm (khác chat riêng 1-1)."""
    return (chat or {}).get("type") in ("group", "supergroup")


def _private_only_reply() -> str:
    """Tin nhắn từ chối khi bấm Nạp/Rút/Tài Khoản TRONG NHÓM (chỉ dùng ở chat riêng)."""
    return ("🔒 <b>CHỈ DÙNG Ở CHAT RIÊNG</b>\n"
            "┌──────────────────────\n"
            "│ Nạp / Rút / Tài Khoản chỉ dùng khi nhắn RIÊNG cho bot.\n"
            f"│ 👉 Nhắn riêng: https://t.me/{BOT_USERNAME}\n"
            "└──────────────────────")


def resolve_button_label(text: str):
    """Khớp text user gửi từ ReplyKeyboard về callback_data.

    Telegram có thể gửi kèm emoji premium (ký tự thay thế U+FFFC) hoặc emoji thường
    đứng trước nhãn -> vẫn phải khớp được. Trả về None nếu không phải nút.
    """
    if not text:
        return None
    t = text.replace("\ufffc", "").strip()
    if t in BUTTON_LABEL_TO_DATA:
        return BUTTON_LABEL_TO_DATA[t]
    # v73: gõ tay tên mục (không dấu "/", kể cả không dấu tiếng Việt) -> mở đúng mục.
    if t.lower() in MENU_TEXT_ALIASES:
        return MENU_TEXT_ALIASES[t.lower()]
    for label, data in BUTTON_LABEL_TO_DATA.items():
        if t == label or t.endswith(label) or label in t:
            return data
    return None


# Hook lấy số dư (bot.py đăng ký) — nút "Tài Khoản" hiện số dư THẬT.
_BALANCE_HANDLER = None
# Hook TÀI KHOẢN đầy đủ (bot.py đăng ký) — (uid) -> str: Số dư + Cấp VIP + Thống kê.
_ACCOUNT_HANDLER = None
# Hook lấy bảng xếp hạng (bot.py đăng ký) — nút "Đua top" hiện top THẬT.
_TOP_HANDLER = None
# Hook GHI NHẬN yêu cầu rút tiền (bot.py đăng ký) — nút "🏦 Rút tiền" ghi vào data.json.
_WITHDRAW_HANDLER = None
# Hook XÁC NHẬN rút tiền (bot.py đăng ký) — (uid, uname) -> str; tạo yêu cầu rút KÈM STK.
_WITHDRAW_CONFIRM_HANDLER = None
# Hook LIÊN KẾT STK (bot.py đăng ký) — (uid, bank_no, bank_name, bank_owner) -> str.
_BANK_LINK_HANDLER = None
# Hook LẤY STK đã liên kết (bot.py đăng ký) — (uid) -> dict | None.
_BANK_GET_HANDLER = None
# Hook SỐ LIỆU người dùng (bot.py đăng ký) — (uid) -> dict {deposit, wagered, balance}.
_STATS_HANDLER = None
# Hook RÚT TIỀN (bot.py đăng ký) — (uid, uname, arg) -> str | (str, reply_markup).
_RUT_HANDLER = None
# Hook NẠP TIỀN (bot.py đăng ký) — (uid, uname, arg) -> str tạo yêu cầu nạp.
_NAP_HANDLER = None
# Hook TẠO YÊU CẦU NẠP + QR (bot.py đăng ký) — (uid, uname, amount) -> (caption, markup, photo_url).
_DEPOSIT_HANDLER = None
# Hook XEM SỐ DƯ (bot.py đăng ký) — (uid) -> str cho lệnh /SD.
_SD_HANDLER = None
# Hook LỊCH SỬ NẠP/RÚT (bot.py đăng ký) — (uid, kind) -> str; kind = "deposit" | "withdraw".
_HISTORY_HANDLER = None
# Trạng thái CHỜ NHẬP STK theo bước: uid -> {"step":..., "data": {...}, "ts": int}
_BANK_PENDING = {}
BANK_PENDING_TTL = 600  # 10 phút
BANK_STEPS = ("bank_no", "bank_name", "bank_owner")
BANK_STEP_PROMPTS = {
    "bank_name": ("🏦 <b>LIÊN KẾT STK — BƯỚC 2/3</b>\n"
                  "┌──────────────────────\n"
                  "│ Nhập <b>TÊN NGÂN HÀNG</b>.\n"
                  "└──────────────────────\n"
                  "👉 vd: <code>Vietcombank</code>  ·  gõ /huy để huỷ."),
    "bank_owner": ("👤 <b>LIÊN KẾT STK — BƯỚC 3/3</b>\n"
                   "┌──────────────────────\n"
                   "│ Nhập <b>TÊN CHỦ TÀI KHOẢN</b>.\n"
                   "└──────────────────────\n"
                   "👉 vd: <code>NGUYEN VAN A</code>  ·  gõ /huy để huỷ."),
}


def set_balance_handler(fn):
    """Đăng ký hàm (uid) -> str hiển thị số dư cho nút "Tài Khoản"."""
    global _BALANCE_HANDLER
    _BALANCE_HANDLER = fn


def set_account_handler(fn):
    """Đăng ký hàm (uid) -> str hiển thị TÀI KHOẢN đầy đủ (Số dư + Cấp VIP + Thống kê)."""
    global _ACCOUNT_HANDLER
    _ACCOUNT_HANDLER = fn


def set_top_handler(fn):
    """Đăng ký hàm () -> str hiển thị bảng xếp hạng cho nút "Đua top"."""
    global _TOP_HANDLER
    _TOP_HANDLER = fn


def set_withdraw_handler(fn):
    """Đăng ký hàm (uid, uname) -> str xử lý yêu cầu rút tiền (ghi data.json)."""
    global _WITHDRAW_HANDLER
    _WITHDRAW_HANDLER = fn


def set_withdraw_confirm_handler(fn):
    """Đăng ký hàm (uid, uname) -> str XÁC NHẬN rút tiền (tạo yêu cầu rút kèm STK)."""
    global _WITHDRAW_CONFIRM_HANDLER
    _WITHDRAW_CONFIRM_HANDLER = fn


def set_bank_link_handler(fn):
    """Đăng ký hàm (uid, bank_no, bank_name, bank_owner) -> str LƯU STK vào data.json."""
    global _BANK_LINK_HANDLER
    _BANK_LINK_HANDLER = fn


def set_bank_get_handler(fn):
    """Đăng ký hàm (uid) -> dict | None lấy STK đã liên kết."""
    global _BANK_GET_HANDLER
    _BANK_GET_HANDLER = fn


def set_stats_handler(fn):
    """Đăng ký hàm (uid) -> dict {deposit, wagered, balance} cho tin nhắn RÚT TIỀN."""
    global _STATS_HANDLER
    _STATS_HANDLER = fn


def set_rut_handler(fn):
    """Đăng ký hàm (uid, uname, arg) xử lý lệnh /rut [số tiền] | /rut all."""
    global _RUT_HANDLER
    _RUT_HANDLER = fn


def set_nap_handler(fn):
    """Đăng ký hàm (uid, uname, arg) xử lý lệnh /nap [số tiền] — tạo yêu cầu nạp."""
    global _NAP_HANDLER
    _NAP_HANDLER = fn


def set_deposit_handler(fn):
    """Đăng ký hàm (uid, uname, amount) -> (caption, markup, photo_url) tạo yêu cầu nạp + QR."""
    global _DEPOSIT_HANDLER
    _DEPOSIT_HANDLER = fn


def set_sd_handler(fn):
    """Đăng ký hàm (uid) -> str xem số dư cho lệnh /SD."""
    global _SD_HANDLER
    _SD_HANDLER = fn


def set_history_handler(fn):
    """Đăng ký hàm (uid, kind) -> str hiển thị LỊCH SỬ NẠP/RÚT thật (kind: deposit|withdraw)."""
    global _HISTORY_HANDLER
    _HISTORY_HANDLER = fn


# v97: hook LỊCH SỬ ROOM (phiên) + LỊCH SỬ CHƠI (cược) — bot.py đăng ký khi khởi động.
_ROOM_HISTORY_HANDLER = None
_BET_HISTORY_HANDLER = None


def set_room_history_handler(fn):
    """Đăng ký hàm (page) -> str hiển thị LỊCH SỬ ROOM TX (các phiên) thật."""
    global _ROOM_HISTORY_HANDLER
    _ROOM_HISTORY_HANDLER = fn


def set_bet_history_handler(fn):
    """Đăng ký hàm (uid, page) -> str hiển thị LỊCH SỬ CHƠI (các lệnh cược) thật."""
    global _BET_HISTORY_HANDLER
    _BET_HISTORY_HANDLER = fn


def get_user_stats(uid: str) -> dict:
    """Số liệu ĐỘNG của người dùng (đã nạp / đã cược / số dư) — phục vụ tin nhắn rút tiền."""
    if _STATS_HANDLER is None:
        return {}
    try:
        return _STATS_HANDLER(str(uid)) or {}
    except Exception:  # noqa: BLE001
        return {}


def build_main_menu_inline_keyboard(is_group: bool = False) -> dict:
    """InlineKeyboard MENU CHÍNH — MỌI emoji là PREMIUM (`icon_custom_emoji_id`).

    v77: TÁCH QUYỀN THEO NGỮ CẢNH.
    • CHAT RIÊNG: đủ 8 nút (Danh sách game + 7 menu).
    • TRONG NHÓM: ẨN Tài Khoản / Nạp Tiền / Rút Tiền (GROUP_HIDDEN) — chỉ để lại các
      nút chơi game + Giới Thiệu / Đua top / Event / Lệnh.
    """
    rows = []
    for row in START_MENU_ROWS:
        r = []
        for label, cb in row:
            if is_group and cb in GROUP_HIDDEN:
                continue
            emoji = REPLY_BUTTON_EMOJI.get(label, "")
            r.append(_btn(label, cb, emoji))
        if r:
            rows.append(r)
    return {"inline_keyboard": rows}


def build_start_markup(is_group: bool = False) -> dict:
    """reply_markup cho /start: ReplyKeyboard theo NGỮ CẢNH (v77).

    • CHAT RIÊNG: ĐỦ 8 nút bấm nhanh (Danh sách game + 7 menu).
    • TRONG NHÓM: CHỈ nút chơi game ("🎮 Danh sách game") — KHÔNG có Nạp/Rút/Tài Khoản.
    ĐỒNG THỜI /start vẫn gửi kèm MENU CHÍNH INLINE + PREMIUM EMOJI ở tin nhắn riêng
    (build_main_menu_inline_keyboard) — trong nhóm cũng ẩn Nạp/Rút/Tài Khoản.
    LƯU Ý: ReplyKeyboard của Telegram KHÔNG render custom/premium emoji trong nhãn nút
    -> nút trên ReplyKeyboard dùng emoji UNICODE; chỉ INLINE mới dùng được premium emoji.
    """
    return build_start_keyboard(is_group)


def build_start_keyboard(is_group: bool = False) -> dict:
    """reply_markup REPLY keyboard — v77: TÁCH QUYỀN NÚT THEO NGỮ CẢNH.

    • is_group=True  -> CHỈ 1 nút "🎮 Danh sách game" (chơi Tài Xỉu trong nhóm).
    • is_group=False -> ĐỦ 8 nút bấm nhanh (chat riêng).
    Nhãn = "<emoji Unicode> <tên mục>". Bấm nút -> Telegram gửi text = nhãn nút;
    resolve_button_label() khớp được cả khi có emoji đứng trước.
    """
    # v88: LUÔN hiển thị 8 nút menu CHÍNH (ReplyKeyboard "tin nhắn nhanh" như bản cũ v76).
    #      13 nút phụ KHÔNG ở đây — chỉ là INLINE gắn vào tin nhắn TÀI KHOẢN.
    rows = []
    for row in START_KEYBOARD_ROWS:
        r = []
        for label, _data in row:
            emoji = REPLY_BUTTON_EMOJI.get(label)
            text = f"{emoji} {label}" if emoji else label
            btn = {"text": text}
            # v89: gắn PREMIUM emoji THẬT cho nút ReplyKeyboard qua `icon_custom_emoji_id`
            # (Bot API 9.4). Telegram hiển thị icon premium ngay TRƯỚC nhãn nút.
            _icon = BUTTON_ICON_IDS.get(label)
            if _icon:
                btn["icon_custom_emoji_id"] = _icon
            r.append(btn)
        rows.append(r)
    return {
        "keyboard": rows,
        "resize_keyboard": True,
        "is_persistent": True,
    }


# v87: InlineKeyboard 13 nút GẮN LIỀN tin nhắn TÀI KHOẢN (theo ẢNH MẪU người dùng).
# Bấm "👤 Tài Khoản" / gõ /tk -> bộ nút INLINE này đi kèm CHÍNH tin nhắn tài khoản
# (KHÔNG phải ReplyKeyboard nổi dưới ô nhập tin nhắn như v84-v86).
# Bố cục: 6 hàng × 2 nút + 1 hàng full-width = 13 nút.
ACCOUNT_INLINE_ROWS = [
    [("LS nạp", "📈", "menu:lsnap"), ("LS rút", "⌛", "menu:lsrut")],
    [("LS chơi", "🕹️", "menu:lschoi"), ("LS Room TX", "📄", "menu:lsroom")],
    [("Nhập giftcode", "🎁", "menu:giftcode"), ("Mua giftcode", "🟣", "menu:muagiftcode")],
    [("Nhận thưởng", "🎁", "menu:nhanthuong"), ("Chuyển tiền", "₿", "menu:chuyentien")],
    [("VIP", "👑", "menu:vip"), ("Fan cứng +30k", "🔥", "menu:fancung")],
    [("Tích lũy nạp", "💎", "menu:tichluy"), ("Két Sắt", "🏦", "menu:ketsat")],
    [("Hỗ trợ", "🦊", "menu:hotro")],
]


def _acct_btn(label: str, emoji: str, cb: str) -> dict:
    """Nút inline cho tin nhắn TÀI KHOẢN: ưu tiên PREMIUM icon (icon_custom_emoji_id).

    Emoji KHÔNG có bản premium -> đặt emoji Unicode ngay trong NHÃN nút (tránh 2 emoji).
    """
    icon = EMOJI_ICON_IDS.get(emoji)
    if icon:
        return {"text": label, "callback_data": cb, "icon_custom_emoji_id": icon}
    return {"text": f"{emoji} {label}", "callback_data": cb}


def build_account_inline_keyboard() -> dict:
    """reply_markup INLINE gắn liền tin nhắn TÀI KHOẢN — 13 nút (6 hàng × 2 + 1 hàng).

    Đúng ẢNH MẪU: bấm '👤 Tài Khoản' / /tk -> các nút nằm NGAY TRONG bong bóng tin nhắn
    tài khoản (InlineKeyboardMarkup), KHÔNG phải ReplyKeyboard.
    """
    rows = []
    for row in ACCOUNT_INLINE_ROWS:
        rows.append([_acct_btn(lbl, emo, cb) for (lbl, emo, cb) in row])
    return {"inline_keyboard": rows}


def build_card_inline_keyboard() -> dict:
    """InlineKeyboard THẬT gắn dưới ẢNH phiên (2 nút cạnh nhau, bấm được).

    Nút trên ảnh chỉ là HÌNH VẼ (không bấm được) — 2 nút này là nút THẬT:
      • "💸 Nạp tiền tại đây ↗️" → callback menu:deposit
      • "🏦 Rút tiền"            → callback menu:withdraw
    """
    return {
        "inline_keyboard": [
            [
                _btn("Nạp tiền tại đây ↗️", "menu:deposit", "💸"),
                _btn("Rút tiền", "menu:withdraw", "🏦"),
            ]
        ]
    }


def _as_reply(res):
    """Chuẩn hoá kết quả handler/hàm trả lời thành (text, reply_markup).

    Hỗ trợ cả 3-tuple (text, reply_markup, photo_url) của luồng gửi ẢNH.
    """
    if isinstance(res, tuple) and len(res) == 3:
        return res[0], res[1]
    if isinstance(res, tuple) and len(res) == 2:
        return res[0], res[1]
    return res, None


def _as_reply_full(res):
    """Chuẩn hoá thành (text, reply_markup, photo_url) — photo_url=None nếu là tin nhắn chữ."""
    if isinstance(res, tuple) and len(res) == 3:
        # v86: chuẩn hoá photo rỗng ("") thành None để KHÔNG gửi sendPhoto rỗng.
        return res[0], res[1], (res[2] or None)
    if isinstance(res, tuple) and len(res) == 2:
        return res[0], res[1], None
    return res, None, None


def build_deposit_denom_keyboard() -> dict:
    """InlineKeyboard 10 nút mệnh giá nạp (2 hàng × 5 nút)."""
    rows, row = [], []
    for amt in DEPOSIT_DENOMS:
        row.append({"text": _fmt_denom(amt), "callback_data": f"dep:{amt}"})
        if len(row) == 5:
            rows.append(row)
            row = []
    if row:
        rows.append(row)
    return {"inline_keyboard": rows}


def build_deposit_choose_reply():
    """Tin nhắn 'Chọn mệnh giá nạp tiền' + 10 nút mệnh giá. Trả (text, reply_markup)."""
    text = (
        "💳 <b>Chọn mệnh giá nạp tiền</b>\n"
        "┌──────────────────────\n"
        f"│ • Nạp tối thiểu: <b>{_fmt_vn(DEPOSIT_MIN)} đ</b>\n"
        f"│ • Nạp tối đa: <b>{_fmt_vn(DEPOSIT_MAX)} đ</b>\n"
        "│ • Bấm vào button dưới để nạp tiền qua <b>Chuyển khoản Ngân hàng</b>\n"
        "└──────────────────────\n"
        "👉️ <b>Cách lấy thông tin nạp:</b>\n"
        "🔶 Gõ lệnh <code>/nap số_tiền</code> (VD <code>/nap 100000</code>)\n"
        "🔶 Hoặc bấm nút số tiền bên dưới để lấy nhanh.\n"
        "⚠️ <b>Lưu ý:</b>\n"
        "✅ Chuyển đúng <b>SỐ TIỀN</b> và <b>NỘI DUNG</b> được cung cấp.\n"
        "✅ Mỗi lần nạp cần lấy thông tin <b>MỚI</b>.\n"
        "⭕ Không dùng thông tin cũ cho giao dịch sau.\n"
        f"💰 Nạp tối thiểu: <b>{_fmt_vn(DEPOSIT_MIN)}đ</b>"
    )
    return (text, build_deposit_denom_keyboard())


def build_deposit_info(amount: int, content: str):
    """Tin nhắn thông tin nạp kèm QR VietQR. Trả (caption, reply_markup, photo_url)."""
    amt = _fmt_vn(amount)
    caption = (
        f"📌 <b>Lệnh nạp {amt} đ đã tạo.</b>\n"
        "┌──────────────────────\n"
        f"│ 🏦 Ngân hàng: <b>{DEPOSIT_BANK_NAME or '—'}</b>\n"
        f"│ 💳 Số TK: <code>{DEPOSIT_BANK_NO}</code>\n"
        f"│ 👤 Chủ TK: <b>{DEPOSIT_BANK_OWNER}</b>\n"
        f"│ 💵 Số tiền: <b>{amt} đ</b>\n"
        f"│ 📝 Nội dung nạp: <code>{content}</code>\n"
        "│ ⏳ Hiệu lực: <b>10 phút</b>\n"
        "└──────────────────────\n"
        "✅ Sau khi chuyển khoản thành công 3p chưa nhận được tiền liên hệ hỗ trợ bên dưới.\n"
        f"🏛 Tham gia Room TX: {ROOM_TX_URL}"
    )
    q = urllib.parse.quote
    photo = (f"https://img.vietqr.io/image/{DEPOSIT_BANK_BIN}-{DEPOSIT_BANK_NO}-compact2.png"
             f"?amount={int(amount)}&addInfo={q(content)}&accountName={q(DEPOSIT_BANK_OWNER)}")
    markup = {"inline_keyboard": [[
        _btn("Tôi đã chuyển khoản", "dep:done", "✅"),
        _btn("Nạp mệnh giá khác", "menu:deposit", "💸"),
    ]]}
    return (caption, markup, photo)


def get_linked_bank(uid: str):
    """Trả về dict STK đã liên kết của người dùng (hoặc None)."""
    if _BANK_GET_HANDLER is None:
        return None
    try:
        return _BANK_GET_HANDLER(str(uid))
    except Exception:  # noqa: BLE001
        return None


def _fmt_bank(bank: dict) -> str:
    """Khối hiển thị STK đã liên kết (GIỮ khung ┌│└)."""
    return ("┌──────────────────────\n"
            f"│ 🏦 Ngân hàng: <b>{bank.get('bank_name', '')}</b>\n"
            f"│ 🔢 Số tài khoản: <code>{bank.get('bank_no', '')}</code>\n"
            f"│ 👤 Chủ tài khoản: <b>{bank.get('bank_owner', '')}</b>\n"
            "└──────────────────────")


def build_withdraw_reply(uid: str):
    """Nút "🏦 Rút tiền" — chưa có STK thì YÊU CẦU liên kết; có rồi thì hiện STK + nút xác nhận."""
    bank = get_linked_bank(uid)
    if not bank:
        text = ("🏦 <b>RÚT TIỀN</b>\n"
                "┌──────────────────────\n"
                "│ ⚠️ Bạn CHƯA liên kết số tài khoản (STK).\n"
                "│ 📝 Cần liên kết STK trước khi rút tiền.\n"
                "└──────────────────────\n\n"
                "👉 Bấm nút bên dưới hoặc gõ <code>/stk</code> để liên kết.\n"
                "Cú pháp nhanh: <code>/stk &lt;số TK&gt; | &lt;ngân hàng&gt; | &lt;chủ TK&gt;</code>")
        kb = {"inline_keyboard": [[_btn("Liên kết STK", "bank:link", "🔗")]]}
        return text, kb
    # ĐÃ liên kết STK → hiện ĐÚNG tin nhắn THÔNG TIN RÚT TIỀN (dữ liệu ĐỘNG theo user).
    stats = get_user_stats(uid)
    deposit = int(stats.get("deposit", 0) or 0)
    wagered = int(stats.get("wagered", 0) or 0)
    moc = deposit + int(NEWBIE_RESERVED) * int(WAGER_MULT)
    du_dieu_kien = wagered >= moc
    stk_line = (f"<blockquote>{bank.get('bank_no', '')} - "
                f"<b>{bank.get('bank_name', '')} - {bank.get('bank_owner', '')}</b></blockquote>")
    lines = [
        "🧾 <b>THÔNG TIN RÚT TIỀN</b>",
        "",
        "STK đã cài đặt của bạn:",
        "",
        stk_line,
        "",
        "<i>Để đổi STK vui lòng liên hệ Admin.</i>",
        "",
        "💸 <b>Rút tiền về tài khoản trên:</b>",
        "• <code>/rut [số tiền]</code> - VD: <code>/rut 50000</code>",
        "• <code>/rut all</code> - Rút tối đa phần khả dụng (đã trừ phí 1%)",
        "",
        "📋 <b>Điều kiện rút tiền:</b>",
        "• Cược đủ mốc tiền nạp + số dư tân thủ giữ lại x3.",
        f"• Số tiền đã nạp: <code>{_fmt_vn(deposit)}</code>",
        f"• Mốc cược cần đủ: <code>{_fmt_vn(moc)}</code>",
        f"• Hiện đã cược: <code>{_fmt_vn(wagered)}</code>",
        "",
    ]
    if du_dieu_kien:
        lines.append("<blockquote>✅ Đã đủ điều kiện! Rút tối đa "
                     f"<code>{_fmt_vn(WITHDRAW_MAX)}</code> mỗi lần.</blockquote>")
    else:
        lines.append("<blockquote>❌ Chưa đủ điều kiện! Còn thiếu "
                     f"<code>{_fmt_vn(max(0, moc - wagered))}</code> cược.</blockquote>")
    lines += [
        "",
        "<blockquote>⚠️ Phí rút <b>1%</b>. Rút tối thiểu theo cài đặt bot "
        "(thường <code>50k</code>).</blockquote>",
    ]
    text = "\n".join(lines)
    kb = {"inline_keyboard": [
        [_btn("Rút tối đa", "rut:all", "💸"),
         _btn("Đổi STK", "bank:link", "✏️")],
    ]}
    return text, kb


def _begin_bank_link(uid: str) -> str:
    """Bắt đầu luồng liên kết STK (bước 1/3) — lưu trạng thái chờ nhập."""
    _BANK_PENDING[str(uid)] = {"step": "bank_no", "data": {}, "ts": int(time.time())}
    return ("🔗 <b>LIÊN KẾT SỐ TÀI KHOẢN (STK)</b>\n"
            "┌──────────────────────\n"
            "│ Bước 1/3 — Nhập <b>SỐ TÀI KHOẢN</b>.\n"
            "└──────────────────────\n"
            "👉 Gõ số tài khoản của bạn (vd: <code>0123456789</code>)\n"
            "Hoặc nhập 1 dòng: <code>/stk &lt;số TK&gt; | &lt;ngân hàng&gt; | &lt;chủ TK&gt;</code>\n"
            "Gõ <code>/huy</code> để huỷ.")


def _finish_bank_link(uid: str, bank_no: str, bank_name: str, bank_owner: str) -> str:
    """Hoàn tất liên kết STK (ghi vào data.json qua handler của bot.py)."""
    if _BANK_LINK_HANDLER is None:
        return "⚠️ Bot chưa sẵn sàng liên kết STK, thử lại sau."
    try:
        return _BANK_LINK_HANDLER(str(uid), bank_no, bank_name, bank_owner)
    except Exception as e:  # noqa: BLE001
        return f"❌ Lỗi liên kết STK: {e}"


# ── Tin nhắn "DANH SÁCH GAME" (theo ẢNH MẪU user gửi) ──────────────────────────
# Lưới nút: 8 hàng game (2 hàng đầu 1 nút, 6 hàng sau 2 nút = ĐÚNG 14 GAME) + 4 hàng menu chính.
# v76: giữ nguyên 14 game (nhãn JILI/PG đã sửa lỗi lặp chữ).
# Nút game: (emoji, NHÃN, callback_data). Emoji CÓ bản premium -> tách khỏi nhãn, gắn `icon_custom_emoji_id`
# (Bot API 9.4). Emoji KHÔNG có bản premium (🎲 🎰 🎴) -> giữ Unicode trong nhãn (quy ước bắt buộc).
GAMES_GRID_ROWS = [
    [("🎲", "Tài Xỉu Tranh Bá", "game:tai_xiu_tranh_ba")],
    [("🔥", "Tài Xỉu Săn Hũ", "game:tai_xiu_san_hu")],
    [("🎲", "Xúc Xắc", "game:xuc_xac"), ("🦀", "Bầu Cua", "game:bau_cua")],
    [("🤘", "Chẵn Lẻ Tele", "game:chan_le"), ("🎰", "Slot Tele", "game:slot_tele")],
    [("⚽️", "Bóng Đá", "game:bong_da"), ("🏀", "Bóng Rổ", "game:bong_ro")],
    [("🎲", "SOLO Xúc Xắc", "game:solo_xuc_xac"), ("✊", "Kéo Búa Bao", "game:keo_bua_bao")],
    [("💰", "Lô Đề", "game:lo_de"), ("", "JILI Slot", "game:jili_slot")],
    [("🎴", "LIVE Casino", "game:live_casino"), ("", "PG Slot", "game:pg_slot")],
]

# ID PREMIUM cho emoji TRÊN NÚT — kiểm chứng ngữ nghĩa qua getCustomEmojiStickers.
GAME_ICON_IDS = {
    "🔥": "5424972470023104089", "🦀": "5222474515887435551", "🤘": "5470076726212042350",
    "⚽️": "5373101763442255191", "🏀": "5384088040677319401", "✊": "5472404692975753822",
    "💰": "5375296873982604963",
}

# Nội dung tin nhắn "GAME TÀI XỈU" (game list / tranh bá) — cập nhật theo yêu cầu.
GAME_TAIXIU_TEXT = (
    "💥 <b>GAME TÀI XỈU SĂN HŨ</b> 💥\n"
    "🏛️ Nhóm chơi game: https://t.me/et99sangame\n"
    "\n"
    "- T: Tổng 3 viên XX từ 11 - 18 Tài.\n"
    "- X: Tổng 3 viên XX từ 3 - 10 Xỉu.\n"
    "- C: Tổng 3 viên XX là Chẵn.\n"
    "- L: Tổng 3 viên XX là Lẻ.\n"
    "\n"
    "📌 Tỷ lệ trả thưởng:\n"
    "- T/X/C/L: x1.95\n"
    "- TC/TL/XC/XL: x3\n"
    "- D1 [mặt]: x5\n"
    "- D2 [2 mặt]: x10\n"
    "- D3 [tổng]: 9/10/11/12 x7; 8/13 x9; 7/14 x12; 6/15 x15; 5/16 x18; 4/17 x25; 3/18 x30\n"
    "\n"
    "👉 Tối thiểu 100 và tối đa mỗi bên 500.000\n"
    "\n"
    "📌 Cách chơi:\n"
    "• T 20000 / X 20000 / C 20000 / L 20000\n"
    "• Cược max số dư/giới hạn: T max / XX MAX\n"
    "• Cược ẩn danh (bot/nhóm): TT/XX/CC/LL [tiền]\n"
    "• Xiên: TC/CT 20000, XL/LX 20000\n"
    "• D1: D1 4 20000\n"
    "• D2: D2 46 20000\n"
    "• D3: D3 13 20000 / D3 13 max / D3 13 all"
)

# Thông tin từng game khi bấm nút trong lưới "Danh sách game".
GAME_INFO = {
    "game:tai_xiu_tranh_ba": (GAME_TAIXIU_TEXT, ""),
    "game:tai_xiu_san_hu": (
        "🔥 <b>TÀI XỈU SĂN HŨ</b>",
        "3 xúc xắc + hũ thưởng · sắp mở.\nHiện đang mở <b>Tài Xỉu Tranh Bá</b>."),
    "game:xuc_xac": ("🎲 <b>XÚC XẮC</b>", "Lắc 3 xúc xắc · sắp mở."),
    "game:bau_cua": ("🦀 <b>BẦU CUA</b>", "Bầu Cua Tôm Cá · sắp mở."),
    "game:chan_le": ("🤘 <b>CHẴN LẺ TELE</b>", "Chẵn/Lẻ · sắp mở."),
    "game:slot_tele": ("🎰 <b>SLOT TELE</b>", "Slot quay số · sắp mở."),
    "game:bong_da": ("⚽ <b>BÓNG ĐÁ</b>", "Cá cược bóng đá · sắp mở."),
    "game:bong_ro": ("🏀 <b>BÓNG RỔ</b>", "Cá cược bóng rổ · sắp mở."),
    "game:solo_xuc_xac": ("🎲 <b>SOLO XÚC XẮC</b>", "Đấu xúc xắc 1v1 · sắp mở."),
    "game:keo_bua_bao": ("✊ <b>KÉO BÚA BAO</b>", "Oẳn tù tì · sắp mở."),
    "game:lo_de": ("💰 <b>LÔ ĐỀ</b>", "Lô đề · sắp mở."),
    "game:jili_slot": ("JILI <b>SLOT</b>", "Slot JILI · sắp mở."),
    "game:live_casino": ("🎴 <b>LIVE CASINO</b>", "Casino trực tiếp · sắp mở."),
    "game:pg_slot": ("PG <b>SLOT</b>", "Slot PG · sắp mở."),
}

# Nội dung tin nhắn — CHÍNH XÁC theo ảnh mẫu (tiêu đề + đủ các game + ví dụ cú pháp cược).
GAMES_LIST_TEXT = (
    "🎮 <b>DANH SÁCH GAME</b>\n"
    "Vui lòng chọn Game\n"
    "\n"
    "🎲 Tài Xỉu Tranh Bá\n"
    "🔥 Tài Xỉu Săn Hũ\n"
    "🎲 Xúc Xắc&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;🦀 Bầu Cua\n"
    "🤘 Chẵn Lẻ Tele&nbsp;&nbsp;🎰 Slot Tele\n"
    "⚽ Bóng Đá&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;🏀 Bóng Rổ\n"
    "🎲 SOLO Xúc Xắc&nbsp;&nbsp;✊ Kéo Búa Bao\n"
    "💰 Lô Đề&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;JILI Slot JILI\n"
    "🎴 LIVE Casino&nbsp;&nbsp;PG Slot PG\n"
    "\n"
    "🎟️ Đặt cược trong nhóm bằng tin nhắn thường (KHÔNG cần dấu /):\n"
    "<code>T 200k X 200k L 500K C 500K</code>"
)


def _game_button(emoji: str, label: str, cb: str) -> dict:
    """1 nút game: CÓ premium -> icon_custom_emoji_id; KHÔNG -> giữ emoji Unicode trong nhãn."""
    icon = GAME_ICON_IDS.get(emoji) if emoji else None
    if icon:
        return {"text": label, "callback_data": cb, "icon_custom_emoji_id": icon}
    txt = f"{emoji} {label}".strip() if emoji else label
    return {"text": txt, "callback_data": cb}


def build_games_keyboard() -> dict:
    """Inline keyboard cho tin nhắn 'Danh sách game' — MỌI emoji trên nút là PREMIUM
    (Bot API 9.4 `icon_custom_emoji_id`). Emoji không có bản premium (🎲 🎰 🎴) giữ Unicode."""
    rows = []
    for r in GAMES_GRID_ROWS:
        rows.append([_game_button(e, lbl, cb) for (e, lbl, cb) in r])
    for r in MENU_ROWS:
        row = []
        for lbl, cb in r:
            btn = {"text": lbl, "callback_data": cb}
            icon = BUTTON_ICON_IDS.get(lbl)  # giữ emoji PREMIUM như các nút khác của bot.
            if icon:
                btn["icon_custom_emoji_id"] = icon
            row.append(btn)
        rows.append(row)
    return {"inline_keyboard": rows}


def _build_games_list_text() -> str:
    """Nội dung tin nhắn 'DANH SÁCH GAME' theo ảnh mẫu."""
    return GAMES_LIST_TEXT


def _callback_reply(data: str, uid: str, uname: str = "") -> str:
    """Nội dung trả lời cho từng nút inline (LUÔN trả về chuỗi, không raise)."""
    data = (data or "").strip()
    if data == "menu:games":
        return (_build_games_list_text(), build_games_keyboard(), None)
    if data == "game:tai_xiu_tranh_ba":
        # Tin nhắn "GAME TÀI XỈU" (game list / tranh bá) — trả về NGUYÊN VĂN nội dung mới.
        return GAME_TAIXIU_TEXT
    if data.startswith("game:"):
        # Bấm 1 game trong lưới -> hiện thông tin game (không báo lỗi).
        title, desc = GAME_INFO.get(
            data, ("🎮 <b>GAME</b>", "Game này sẽ sớm mở. Hiện đang mở <b>Tài Xỉu Tranh Bá</b>."))
        return (f"{title}\n{desc}\n\n"
                "🎟️ Đặt cược trong nhóm bằng tin nhắn thường (KHÔNG cần dấu /).")
    if data in ("menu:account", "menu:account_kb"):
        # v81: TÀI KHOẢN đầy đủ (Số dư + Cấp VIP + Thống kê) nếu bot.py đã đăng ký hook.
        # v87: gửi KÈM InlineKeyboard 13 nút GẮN LIỀN tin nhắn tài khoản (theo ảnh mẫu).
        #      KHÔNG dùng ReplyKeyboard nữa (v84-v86 đặt nút ở bàn phím tin nhắn nhanh -> sai).
        _kb = build_account_inline_keyboard()
        if _ACCOUNT_HANDLER is not None:
            try:
                return (_ACCOUNT_HANDLER(uid), _kb, None)
            except Exception as e:  # noqa: BLE001
                return (f"⚠️ Lỗi đọc tài khoản: {e}", _kb, None)
        if _BALANCE_HANDLER is not None:
            try:
                bal = _BALANCE_HANDLER(uid)
            except Exception as e:  # noqa: BLE001
                bal = f"(lỗi đọc số dư: {e})"
        else:
            bal = "(chưa sẵn sàng)"
        return (f"🧾 <b>TÀI KHOẢN</b>\n🆔 ID: <code>{uid}</code>\n💳 Số dư: {bal}", _kb, None)
    if data == "menu:deposit":
        # Nút "💸 Nạp tiền tại đây ↗️" — hiện tin nhắn CHỌN MỆNH GIÁ + 10 nút mệnh giá.
        return build_deposit_choose_reply()
    if data.startswith("dep:"):
        # Nút mệnh giá (dep:<amount>) hoặc "✅ Tôi đã chuyển khoản" (dep:done).
        sub = data.split(":", 1)[1]
        if sub == "done":
            return ("✅ <b>Đã ghi nhận!</b>\n"
                    "Vui lòng chờ admin duyệt. Sau khi chuyển khoản thành công 3 phút "
                    "chưa nhận được tiền, liên hệ hỗ trợ bên dưới.\n"
                    f"🏛 Tham gia Room TX: {ROOM_TX_URL}")
        if _DEPOSIT_HANDLER is None:
            return "⚠️ Bot chưa sẵn sàng nạp tiền, thử lại sau."
        try:
            return _DEPOSIT_HANDLER(uid, uname, sub)
        except Exception as e:  # noqa: BLE001
            return f"❌ Lỗi tạo yêu cầu nạp: {e}"
    if data == "menu:withdraw":
        # Nút "🏦 Rút tiền" — CHƯA có STK thì YÊU CẦU liên kết; có rồi thì hiện STK + nút xác nhận.
        return build_withdraw_reply(uid)
    if data == "bank:link":
        # Nút "🔗 Liên kết STK" — bắt đầu luồng nhập STK theo bước.
        return _begin_bank_link(uid)
    if data == "wd:go":
        # Nút "✅ Xác nhận rút tiền" — CHỈ cho rút khi đã liên kết STK.
        bank = get_linked_bank(uid)
        if not bank:
            return build_withdraw_reply(uid)
        if _WITHDRAW_CONFIRM_HANDLER is not None:
            try:
                return _WITHDRAW_CONFIRM_HANDLER(uid, "")
            except Exception as e:  # noqa: BLE001
                return f"❌ Lỗi xử lý yêu cầu rút tiền: {e}"
        return build_withdraw_reply(uid)
    if data == "menu:intro":
        return ("🌸 <b>GIỚI THIỆU</b>\n\n"
                f"Mời bạn bè cùng tham gia Room TX để săn hũ: {ROOM_TX_URL}")
    if data == "menu:top":
        if _TOP_HANDLER is not None:
            try:
                return _TOP_HANDLER()
            except Exception as e:  # noqa: BLE001
                return f"⚠️ Không đọc được bảng xếp hạng: {e}"
        return "🏆 Bảng xếp hạng chưa sẵn sàng."
    if data == "menu:event":
        return ("🎁 <b>EVENT</b>\n\n"
                f"Nhận giftcode hằng ngày tại Room TX: {ROOM_TX_URL}")
    if data == "menu:commands":
        return ("🔍 <b>LỆNH</b>\n\n"
                "• /start — bắt đầu\n"
                "• Đặt cược: gõ tin nhắn thường, KHÔNG cần dấu /\n"
                "  Ví dụ: <code>T 200k X 200k L 500K C 500K</code>\n"
                "  (T=Tài, X=Xỉu, C=Chẵn, L=Lẻ, B=Bão; k=nghìn, m=triệu)")
    # ── v84: 13 nút ReplyKeyboard mới (theo ảnh mẫu) ──
    if data == "menu:lsnap":
        # v93: hiển thị LỊCH SỬ NẠP THẬT từ data.json (deposit_requests).
        if _HISTORY_HANDLER is not None:
            try:
                return _HISTORY_HANDLER(uid, "deposit")
            except Exception as e:  # noqa: BLE001
                return f"⚠️ Không đọc được lịch sử nạp: {e}"
        return ("📈 <b>LỊCH SỬ NẠP</b>\n\n"
                "Chưa có dữ liệu hiển thị. Vui lòng nạp tiền để xem lịch sử.")
    if data == "menu:lsrut":
        # v93: hiển thị LỊCH SỬ RÚT THẬT từ data.json (withdraw_requests).
        if _HISTORY_HANDLER is not None:
            try:
                return _HISTORY_HANDLER(uid, "withdraw")
            except Exception as e:  # noqa: BLE001
                return f"⚠️ Không đọc được lịch sử rút: {e}"
        return ("⌛ <b>LỊCH SỬ RÚT</b>\n\n"
                "Chưa có dữ liệu hiển thị. Vui lòng rút tiền để xem lịch sử.")
    if data == "menu:lschoi":
        # v97: hiển thị LỊCH SỬ CHƠI THẬT từ data.json (user["bet_history"]).
        if _BET_HISTORY_HANDLER is not None:
            try:
                return _BET_HISTORY_HANDLER(uid, 1)
            except Exception as e:  # noqa: BLE001
                return f"⚠️ Không đọc được lịch sử chơi: {e}"
        return ("🕹️ <b>LỊCH SỬ CHƠI</b>\n\n"
                "Chưa có dữ liệu hiển thị. Hãy đặt cược để xem lịch sử.")
    if data == "menu:lsroom":
        # v97: hiển thị LỊCH SỬ ROOM TX THẬT từ round_history.json (các phiên).
        if _ROOM_HISTORY_HANDLER is not None:
            try:
                return _ROOM_HISTORY_HANDLER(1)
            except Exception as e:  # noqa: BLE001
                return f"⚠️ Không đọc được lịch sử phòng: {e}"
        return (f"📄 <b>LỊCH SỬ ROOM TX</b>\n\n"
                f"Tham gia Room TX để xem lịch sử: {ROOM_TX_URL}")
    if data == "menu:giftcode":
        return ("🎁 <b>NHẬP GIFTCODE</b>\n\n"
                "Gõ giftcode của bạn để nhận thưởng.")
    if data == "menu:muagiftcode":
        return ("🟣 <b>MUA GIFTCODE</b>\n\n"
                f"Liên hệ hỗ trợ để mua giftcode: {ROOM_TX_URL}")
    if data == "menu:nhanthuong":
        return ("🎁 <b>NHẬN THƯỞNG</b>\n\n"
                "Chưa có phần thưởng nào để nhận. Hãy chơi để tích lũy!")
    if data == "menu:chuyentien":
        return ("₿ <b>CHUYỂN TIỀN</b>\n\n"
                "Gõ: <code>chuyentien &lt;ID&gt; &lt;số tiền&gt;</code> để chuyển tiền cho người khác.")
    if data == "menu:vip":
        return ("👑 <b>VIP</b>\n\n"
                "Nạp càng nhiều, cấp VIP càng cao:\n"
                "• VIP 0 🥉 Đồng\n• VIP 1 🥈 Bạc\n• VIP 2 🥇 Vàng\n"
                "• VIP 3 💎 Kim Cương\n• VIP 4 👑 Hoàng Kim")
    if data == "menu:fancung":
        return ("🔥 <b>FAN CỨNG +30K</b>\n\n"
                "Tham gia Room TX và tương tác để nhận +30.000 thưởng fan cứng!")
    if data == "menu:tichluy":
        return ("💎 <b>TÍCH LŨY NẠP</b>\n\n"
                "Nạp đủ mốc để nhận thưởng tích lũy. Xem chi tiết tại Room TX.")
    if data == "menu:ketsat":
        return ("🏦 <b>KÉT SẮT</b>\n\n"
                "Két sắt giữ tiền an toàn. Tính năng sắp ra mắt.")
    if data == "menu:hotro":
        return (f"🦊 <b>HỖ TRỢ</b>\n\n"
                f"Liên hệ hỗ trợ 24/7: {ROOM_TX_URL}")
    if data == "rut:all":
        # Nút "💸 Rút tối đa" — rút tối đa phần khả dụng (đã trừ phí 1%).
        if _RUT_HANDLER is None:
            return "⚠️ Bot chưa sẵn sàng rút tiền, thử lại sau."
        try:
            res = _RUT_HANDLER(uid, uname, "all")
        except Exception as e:  # noqa: BLE001
            return f"❌ Lỗi rút tiền: {e}"
        return _as_reply(res)[0]
    return "ℹ️ Nút không xác định."


class TelegramCommandPoller:
    """Long-poll getUpdates để xử lý các lệnh Telegram (vd /webadmin)."""

    def __init__(self, token: str, timeout: int = 30):
        self.token = (token or "").strip()
        self.timeout = timeout
        self.enabled = bool(self.token and aiohttp is not None)
        self._offset = 0
        self._task = None

    async def _call(self, method: str, payload: dict) -> dict:
        url = TELEGRAM_API.format(token=self.token, method=method)
        timeout = aiohttp.ClientTimeout(total=self.timeout + 10)
        async with aiohttp.ClientSession(timeout=timeout) as session:
            async with session.post(url, json=payload) as resp:
                return await resp.json(content_type=None)

    async def _send(self, chat_id, text: str, reply_markup=None):
        try:
            payload = {
                "chat_id": chat_id,
                "text": _premiumize(text),
                "parse_mode": "HTML",
                # TẮT preview link: tránh ảnh preview lớn chen vào giữa tin nhắn/làm nghẽn client.
                "link_preview_options": {"is_disabled": True},
            }
            if reply_markup is not None:
                payload["reply_markup"] = reply_markup
            await self._call("sendMessage", payload)
        except Exception:  # noqa: BLE001
            pass

    async def _send_photo(self, chat_id, photo_url: str, caption: str = "", reply_markup=None):
        """Gửi ẢNH (QR chuyển khoản) kèm caption + inline keyboard."""
        try:
            payload = {
                "chat_id": chat_id,
                "photo": photo_url,
                "caption": _premiumize(caption or ""),
                "parse_mode": "HTML",
            }
            if reply_markup is not None:
                payload["reply_markup"] = reply_markup
            await self._call("sendPhoto", payload)
        except Exception:  # noqa: BLE001
            pass

    async def _answer_callback(self, callback_id: str, text: str = ""):
        """Trả lời callback (bắt buộc để Telegram hết "loading" trên nút)."""
        try:
            await self._call("answerCallbackQuery", {
                "callback_query_id": callback_id,
                "text": (text or "")[:200],
            })
        except Exception:  # noqa: BLE001
            pass

    async def _handle_callback(self, cq: dict):
        """Xử lý khi người dùng bấm 1 trong 8 nút inline dưới /start."""
        try:
            data = (cq.get("data") or "").strip()
            cq_id = cq.get("id") or ""
            msg = cq.get("message") or {}
            chat = msg.get("chat") or {}
            chat_id = chat.get("id")
            from_user = cq.get("from") or {}
            uid = str(from_user.get("id") or "")
            uname = from_user.get("username") or from_user.get("first_name") or uid
            # v77: Nạp/Rút/Tài Khoản bấm TRONG NHÓM -> từ chối, chỉ dùng ở chat riêng.
            if _is_group_chat(chat) and data in GROUP_HIDDEN:
                await self._answer_callback(cq_id)
                if chat_id is not None:
                    await self._send(chat_id, _private_only_reply())
                return
            reply, markup, photo = _as_reply_full(_callback_reply(data, uid, uname))
            await self._answer_callback(cq_id)
            if chat_id is not None:
                if photo:
                    await self._send_photo(chat_id, photo, reply, reply_markup=markup)
                else:
                    await self._send(chat_id, reply, reply_markup=markup)
        except Exception as e:  # noqa: BLE001
            print(f"⚠️ Lỗi xử lý callback Telegram: {e}")

    async def _handle_update(self, update: dict):
        # Bọc try/except để bot LUÔN trả lời kể cả khi có lỗi bất ngờ.
        try:
            # Nút inline: callback_query (không phải message).
            cq = update.get("callback_query")
            if cq:
                await self._handle_callback(cq)
                return
            msg = update.get("message") or update.get("edited_message") or {}
            text = (msg.get("text") or "").strip()
            chat = msg.get("chat") or {}
            chat_id = chat.get("id")
            from_user = msg.get("from") or {}
            if not text or chat_id is None:
                return

            # Chuẩn hóa: bỏ phần @botname nếu có (vd /webadmin@MyBot)
            cmd = text.split()[0].split("@")[0].lower()
            is_group = _is_group_chat(chat)
            # v77: Nạp/Rút/Tài Khoản CHỈ dùng ở CHAT RIÊNG — trong NHÓM thì từ chối.
            if is_group and cmd in ("/nap", "/rut", "/tk", "/taikhoan", "/account"):
                await self._send(chat_id, _private_only_reply())
                return

            # ── Luồng LIÊN KẾT STK theo bước: nếu đang chờ nhập thì bắt text làm câu trả lời ──
            if cmd == "/nhaplai":
                _BANK_PENDING.pop(str(from_user.get("id") or ""), None)
                await self._send(chat_id, _begin_bank_link(str(from_user.get("id") or "")))
                return
            if cmd == "/huy":
                _BANK_PENDING.pop(str(from_user.get("id") or ""), None)
                await self._send(chat_id, "❌ Đã huỷ liên kết STK.")
                return
            pend = _BANK_PENDING.get(str(from_user.get("id") or ""))
            if pend is not None and not cmd.startswith("/"):
                # Hết hạn thì bỏ trạng thái chờ.
                if int(time.time()) - int(pend.get("ts", 0)) > BANK_PENDING_TTL:
                    _BANK_PENDING.pop(str(from_user.get("id") or ""), None)
                else:
                    step = pend.get("step")
                    data_bank = pend.get("data", {})
                    data_bank[step] = text.strip()
                    pend["ts"] = int(time.time())
                    idx = BANK_STEPS.index(step)
                    if idx + 1 < len(BANK_STEPS):
                        nxt = BANK_STEPS[idx + 1]
                        pend["step"] = nxt
                        await self._send(chat_id, BANK_STEP_PROMPTS[nxt])
                    else:
                        _BANK_PENDING.pop(str(from_user.get("id") or ""), None)
                        await self._send(chat_id, _finish_bank_link(
                            str(from_user.get("id") or ""),
                            data_bank.get("bank_no", ""),
                            data_bank.get("bank_name", ""),
                            data_bank.get("bank_owner", "")))
                    return

            if cmd == "/addcoin":
                # /addcoin <user_id> <amount> — CHỈ admin. Người thường: IM LẶNG (không lộ lệnh tồn tại).
                if _is_admin(from_user):
                    if _ADDCOIN_HANDLER is None:
                        await self._send(chat_id, "⚠️ Bot chưa sẵn sàng cộng xu, thử lại sau.")
                    else:
                        parts = text.split()
                        if len(parts) < 3:
                            await self._send(chat_id, "❌ Cú pháp: /addcoin <user_id> <số xu>")
                        else:
                            try:
                                reply = _ADDCOIN_HANDLER(parts[1], parts[2])
                            except Exception as e:  # noqa: BLE001
                                reply = f"❌ Lỗi cộng xu: {e}"
                            await self._send(chat_id, reply)
            elif cmd == "/webadmin":
                # Lệnh ẨN khỏi menu — CHỈ admin dùng được. Người thường: im lặng.
                if _is_admin(from_user):
                    url = read_webadmin_url()
                    if url:
                        await self._send(chat_id,
                            "🖥 <b>WEB ADMIN</b>\n"
                            "┌──────────────────────\n"
                            f"│ 🔗 Link: {url}\n"
                            "│ 👤 User: <code>admin</code>\n"
                            f"│ 🔑 Pass: <code>{ADMIN_PASSWORD}</code>\n"
                            "└──────────────────────\n"
                            "⚠️ Link chạy qua tunnel tạm, có thể đổi sau khi restart.")
                    else:
                        local = os.getenv("WEBADMIN_LOCAL_URL", "http://127.0.0.1:5000/").strip()
                        await self._send(chat_id,
                            "🖥 <b>WEB ADMIN</b> (chưa có link public)\n"
                            "┌──────────────────────\n"
                            f"│ 🏠 Local: {local}\n"
                            "│ 👤 User: <code>admin</code>\n"
                            f"│ 🔑 Pass: <code>{ADMIN_PASSWORD}</code>\n"
                            "└──────────────────────\n"
                            "ℹ️ Chưa bật tunnel public — dùng trên máy chủ hoặc bật tunnel để có link.")
            elif cmd in ("/stk", "/stkbank"):
                # Xem / đổi STK đã liên kết. Cú pháp 1 dòng: /stk <số TK> | <ngân hàng> | <chủ TK>
                uid = str(from_user.get("id") or "")
                rest = text.split(None, 1)[1].strip() if len(text.split(None, 1)) > 1 else ""
                bank = get_linked_bank(uid)
                if rest:
                    parts = [p.strip() for p in rest.split("|")]
                    if len(parts) == 3 and all(parts):
                        await self._send(chat_id, _finish_bank_link(uid, parts[0], parts[1], parts[2]))
                    else:
                        await self._send(chat_id,
                            "❌ Cú pháp: <code>/stk &lt;số TK&gt; | &lt;ngân hàng&gt; | &lt;chủ TK&gt;</code>")
                elif not bank:
                    await self._send(chat_id, _begin_bank_link(uid))
                else:
                    await self._send(chat_id,
                        "🏦 <b>STK ĐÃ LIÊN KẾT</b>\n" + _fmt_bank(bank) +
                        "\n👉 Bấm nút để ĐỔI STK hoặc gõ <code>/stk &lt;số TK&gt; | &lt;ngân hàng&gt; | &lt;chủ TK&gt;</code>",
                        reply_markup={"inline_keyboard": [[
                            _btn("Đổi STK", "bank:link", "✏️")]]})
            elif cmd in ("/sd", "/sodu", "/balance"):
                # Lệnh /SD — xem SỐ DƯ hiện tại + tổng nạp + tổng rút.
                uid = str(from_user.get("id") or "")
                if _SD_HANDLER is not None:
                    try:
                        _bal = _SD_HANDLER(uid)
                    except Exception as e:  # noqa: BLE001
                        _bal = f"(lỗi đọc số dư: {e})"
                elif _BALANCE_HANDLER is not None:
                    try:
                        _bal = _BALANCE_HANDLER(uid)
                    except Exception as e:  # noqa: BLE001
                        _bal = f"(lỗi đọc số dư: {e})"
                else:
                    _bal = "(chưa sẵn sàng)"
                await self._send(chat_id, _bal)
            elif cmd in ("/tk", "/taikhoan", "/account"):
                # Lệnh /tk — xem TÀI KHOẢN (số dư + ID) KÈM ReplyKeyboard 13 nút (v86).
                uid = str(from_user.get("id") or "")
                uname = from_user.get("username") or from_user.get("first_name") or uid
                _at, _am, _ap = _as_reply_full(_callback_reply("menu:account_kb", uid, uname))
                await self._send(chat_id, _at, reply_markup=_am)
            elif cmd in ("/gt", "/gioithieu", "/intro"):
                # Lệnh /gt — GIỚI THIỆU bạn bè.
                await self._send(chat_id, _callback_reply("menu:intro", "", ""))
            elif cmd in ("/top", "/duatop", "/bxh"):
                # Lệnh /top — bảng ĐUA TOP.
                await self._send(chat_id, _callback_reply("menu:top", "", ""))
            elif cmd in ("/event", "/sukien"):
                # Lệnh /event — xem EVENT / giftcode.
                await self._send(chat_id, _callback_reply("menu:event", "", ""))
            elif cmd in ("/lenh", "/commands"):
                # Lệnh /lenh — danh sách LỆNH.
                await self._send(chat_id, _callback_reply("menu:commands", "", ""))
            elif cmd == "/rut":
                # Lệnh /rut [số tiền] | /rut all — rút tiền về STK đã liên kết.
                uid = str(from_user.get("id") or "")
                uname = from_user.get("username") or from_user.get("first_name") or uid
                rest = text.split(None, 1)[1].strip() if len(text.split(None, 1)) > 1 else ""
                if _RUT_HANDLER is None:
                    await self._send(chat_id, "⚠️ Bot chưa sẵn sàng rút tiền, thử lại sau.")
                else:
                    try:
                        res = _RUT_HANDLER(uid, uname, rest)
                    except Exception as e:  # noqa: BLE001
                        res = f"❌ Lỗi rút tiền: {e}"
                    reply, markup = _as_reply(res)
                    await self._send(chat_id, reply, reply_markup=markup)
            elif cmd == "/nap":
                # Lệnh /nap [số tiền] — tạo YÊU CẦU NẠP (pending) để admin duyệt trên web admin.
                uid = str(from_user.get("id") or "")
                uname = from_user.get("username") or from_user.get("first_name") or uid
                rest = text.split(None, 1)[1].strip() if len(text.split(None, 1)) > 1 else ""
                if _NAP_HANDLER is None:
                    await self._send(chat_id, "⚠️ Bot chưa sẵn sàng nạp tiền, thử lại sau.")
                else:
                    try:
                        res = _NAP_HANDLER(uid, uname, rest)
                    except Exception as e:  # noqa: BLE001
                        res = f"❌ Lỗi tạo yêu cầu nạp: {e}"
                    reply, markup, photo = _as_reply_full(res)
                    if photo:
                        await self._send_photo(chat_id, photo, reply, reply_markup=markup)
                    else:
                        await self._send(chat_id, reply, reply_markup=markup)
            elif cmd in ("/start", "/help"):
                uid = str(from_user.get("id") or "")
                # v71: ReplyKeyboard (nút 'Danh sách game') gửi RIÊNG, KHÔNG trộn inline.
                await self._send(chat_id, _welcome_text(uid),
                                 reply_markup=build_start_markup(is_group))
                # Menu chính (7 nút) gửi ở TIN NHẮN RIÊNG dạng inline keyboard.
                await self._send(chat_id, "🎛️ <b>MENU CHÍNH</b>",
                                 reply_markup=build_main_menu_inline_keyboard(is_group))
            elif resolve_button_label(text) is not None:
                # Bấm nút trên REPLY keyboard -> Telegram gửi text = nhãn nút.
                uid = str(from_user.get("id") or "")
                uname = from_user.get("username") or from_user.get("first_name") or uid
                data = resolve_button_label(text)
                # v77: gõ/bấm Nạp/Rút/Tài Khoản TRONG NHÓM -> từ chối, chỉ dùng ở chat riêng.
                if is_group and data in GROUP_HIDDEN:
                    await self._send(chat_id, _private_only_reply())
                    return
                # Nút "Rút Tiền": CHƯA có STK → yêu cầu liên kết; có rồi → hiện STK + nút xác nhận.
                reply, markup, photo = _as_reply_full(_callback_reply(data, uid, uname))
                if photo:
                    await self._send_photo(chat_id, photo, reply, reply_markup=markup)
                else:
                    await self._send(chat_id, reply, reply_markup=markup)
            elif _BET_HANDLER is not None and bet_parser.is_bet_message(text):
                # Nhận cược TRỰC TIẾP từ tin nhắn chat thường (không cần dấu /).
                # Tin nhắn chat bình thường khác sẽ không khớp -> bỏ qua, không phản hồi.
                uid = str(from_user.get("id") or "")
                uname = from_user.get("username") or from_user.get("first_name") or uid
                try:
                    reply = _BET_HANDLER(uid, uname, text)
                except Exception as e:  # noqa: BLE001
                    reply = f"❌ Lỗi xử lý cược: {e}"
                await self._send(chat_id, reply)
        except Exception as e:  # noqa: BLE001
            print(f"⚠️ Lỗi xử lý lệnh Telegram: {e}")

    async def _set_public_commands(self):
        """Đăng ký menu lệnh công khai — ẨN /addcoin và /webadmin khỏi menu Telegram."""
        try:
            await self._call("setMyCommands", {
                "commands": [
                    {"command": "start", "description": "Bắt đầu / xem ID"},
                    {"command": "help", "description": "Trợ giúp"},
                    {"command": "sd", "description": "Xem số dư"},
                    {"command": "nap", "description": "Nạp tiền"},
                    {"command": "rut", "description": "Rút tiền"},
                    {"command": "tk", "description": "Tài khoản"},
                    {"command": "gt", "description": "Giới thiệu"},
                    {"command": "top", "description": "Đua top cược"},
                    {"command": "event", "description": "Event"},
                    {"command": "lenh", "description": "Danh sách lệnh"},
                ]
            })
        except Exception:  # noqa: BLE001
            pass

    async def _loop(self):
        # Đăng ký menu lệnh công khai (ẩn /addcoin, /webadmin).
        await self._set_public_commands()
        # Bỏ qua các update cũ tồn đọng trước khi bot khởi động.
        try:
            init = await self._call("getUpdates", {"timeout": 0, "offset": -1})
            if init.get("ok") and init.get("result"):
                self._offset = init["result"][-1]["update_id"] + 1
        except Exception:  # noqa: BLE001
            pass

        while True:
            try:
                data = await self._call("getUpdates", {
                    "timeout": self.timeout,
                    "offset": self._offset,
                    "allowed_updates": ["message", "edited_message", "callback_query"],
                })
                if data.get("ok"):
                    for upd in data.get("result", []):
                        self._offset = upd["update_id"] + 1
                        await self._handle_update(upd)
            except Exception:  # noqa: BLE001
                await asyncio.sleep(3)

    def start(self):
        """Khởi động poller như 1 task nền (gọi trong on_ready)."""
        if not self.enabled:
            print("ℹ️ Lệnh Telegram /webadmin: TẮT (thiếu token hoặc aiohttp).")
            return None
        if self._task is None or self._task.done():
            self._task = asyncio.create_task(self._loop())
            print("✅ Đã bật lệnh Telegram /webadmin (long-polling).")
        return self._task